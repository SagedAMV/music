# Keep Room models
-keep class com.tatbiqi.app.data.model.** { *; }

# Firebase/Firestore requires
-keepattributes Signature
-keepattributes *Annotation*

# Coil
-dontwarn coil.**
