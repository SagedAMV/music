package com.tatbiqi.app.ui.screens

import com.tatbiqi.app.data.model.OrderItem
import com.tatbiqi.app.data.model.Segment
import org.json.JSONArray

/** فك تشفير segmentsJson إلى قائمة كائنات Segment للعرض. */
fun segmentFrom(json: String): List<Segment> {
    return try {
        val arr = JSONArray(json)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val itemsArr = o.optJSONArray("items") ?: JSONArray()
            val items = (0 until itemsArr.length()).mapNotNull { j ->
                val io = itemsArr.getJSONObject(j)
                OrderItem(
                    name = io.optString("name"), quantity = io.optInt("quantity"),
                    buyPrice = io.optInt("buyPrice"), price = io.optInt("price"),
                    size = io.optString("size"), color = io.optString("color"),
                    imageUrl = io.optString("imageUrl")
                )
            }
            Segment(
                shopId = o.optString("shopId"), shopName = o.optString("shopName"),
                status = o.optString("status", "pending"), items = items,
                costAmount = o.optInt("costAmount"), cash = o.optInt("cash"),
                paid = o.optBoolean("paid"), paidActualAmount = o.optInt("paidActualAmount")
            )
        }
    } catch (e: Exception) { emptyList() }
}
