package com.tatbiqi.app.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.tatbiqi.app.data.repository.AppRepository
import com.tatbiqi.app.data.session.SessionManager

fun authViewModelFactory(repo: AppRepository, session: SessionManager): ViewModelProvider.Factory =
    object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            AuthViewModel(repo, session) as T
    }

fun mainViewModelFactory(repo: AppRepository): ViewModelProvider.Factory =
    object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            MainViewModel(repo) as T
    }
