package com.tatbiqi.app.ui.screens.users

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.data.model.User
import com.tatbiqi.app.ui.components.EmptyState
import com.tatbiqi.app.ui.components.LabeledField
import com.tatbiqi.app.ui.components.PrimaryButton
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel

/**
 * إدارة المستخدمين (المالك فقط) — محاكاة renderUsers + confirmAddUser + togglePerm + toggleUser.
 */
@Composable
fun UsersScreen(vm: MainViewModel, auth: AuthViewModel) {
    val users by vm.users.collectAsState()
    var showAdd by remember { mutableStateOf(false) }

        Column(Modifier.fillMaxWidth().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("👥 إدارة المستخدمين", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = { showAdd = true }) { Text("+ مشتري") }
        }
        LazyColumn(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // بانر التكرارات
            val dups = vm.checkAllDuplicates()
            if (dups.isNotEmpty()) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2))) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("⚠️ يوجد ${dups.size} اسم مكرر", color = Color(0xFFB91C1C), modifier = Modifier.weight(1f))
                            TextButton(onClick = { vm.cleanupDuplicates() }) { Text("🧹 تنظيف") }
                        }
                    }
                }
            }
            if (users.isEmpty()) {
                item { EmptyState("لا يوجد مستخدمون", "👥") }
            } else {
                items(users) { u -> UserCard(u, vm) }
            }
        }
    }

    if (showAdd) {
        AddUserDialog(onDismiss = { showAdd = false }, onAdd = { username, pass, name, grantDel ->
            vm.addUser(username, pass, name, grantDel)
            showAdd = false
        })
    }
}

@Composable
fun UserCard(u: User, vm: MainViewModel) {
    val isOwner = u.role == "owner"
    Card(
        colors = CardDefaults.cardColors(containerColor =
            if (isOwner) Color(0xFFFFFBEB) else MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(if (isOwner) "👑 @${u.username}" else "🛍️ @${u.username} (${u.name})",
                    style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.weight(1f))
                if (!isOwner) {
                    Text(
                        if (u.isActive) "مفعّل" else "معطّل",
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            .background(if (u.isActive) Color(0xFF10B981) else Color(0xFFEF4444),
                                androidx.compose.foundation.shape.RoundedCornerShape(50))
                    )
                }
            }
            if (isOwner) {
                Text("صلاحيات كاملة — ينشئ ويعدّل كل الطلبات", style = MaterialTheme.typography.bodySmall)
            } else {
                if (authHasDelivery(u)) Text("📦 لديه صلاحية التسليم", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                Text("الصلاحيات:", style = MaterialTheme.typography.labelMedium)
                permEntries.forEach { (key, label) ->
                    val on = u.has(key)
                    Row(Modifier.fillMaxWidth().clickable { vm.setUserPermission(u.id, key, !on) }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = on, onCheckedChange = { vm.setUserPermission(u.id, key, it) })
                        Text(label, modifier = Modifier.weight(1f))
                    }
                }
                Row {
                    TextButton(onClick = { vm.toggleUserActive(u.id) }) {
                        Text(if (u.isActive) "تعطيل" else "تفعيل")
                    }
                    TextButton(onClick = { vm.deleteUser(u.id) }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }
}

private fun authHasDelivery(u: User): Boolean = u.has("delivery.view") || u.has("delivery.confirm")

private val permEntries = listOf(
    "segments.confirm" to "تأكيد شرائح المحلات",
    "delivery.view" to "عرض التسليم",
    "delivery.confirm" to "تأكيد التسليم",
    "customers.view" to "عرض الزبائن",
    "shops.view" to "عرض المحلات",
    "reports.view" to "عرض التقارير",
    "orders.viewAssigned" to "عرض الطلبات المخصصة"
)

@Composable
fun AddUserDialog(onDismiss: () -> Unit, onAdd: (String, String, String, Boolean) -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var grantDelivery by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("مشتري جديد") },
        text = {
            Column {
                LabeledField(username, { username = it }, "اسم المستخدم")
                Spacer(Modifier.height(8.dp))
                LabeledField(password, { password = it }, "كلمة المرور")
                Spacer(Modifier.height(8.dp))
                LabeledField(name, { name = it }, "الاسم (اختياري)")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = grantDelivery, onCheckedChange = { grantDelivery = it })
                    Text("منح صلاحية التسليم (تم التسليم)")
                }
            }
        },
        confirmButton = { PrimaryButton("إضافة") { onAdd(username, password, name, grantDelivery) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
