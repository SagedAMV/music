package com.tatbiqi.app.ui.screens.shop

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.data.model.Shop
import com.tatbiqi.app.ui.components.EmptyState
import com.tatbiqi.app.ui.components.LabeledField
import com.tatbiqi.app.ui.components.PrimaryButton
import com.tatbiqi.app.ui.motion.motionPress
import com.tatbiqi.app.ui.navigation.Views
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel

/** شاشة المحلات — محتوى تبويب shops (مطابق renderShops في HTML). */
@Composable
fun ShopsScreen(
    vm: MainViewModel,
    auth: AuthViewModel,
    navigateTo: (String, Map<String, String>) -> Unit
) {
    val shops by vm.shops.collectAsState()
    val products by vm.products.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Shop?>(null) }
    val isBuyer = auth.currentUser()?.role == "buyer"

    Column(Modifier.fillMaxWidth().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("🏪 المحلات", style = MaterialTheme.typography.headlineSmall)
            if (auth.has("shops.manage")) {
                TextButton(onClick = { editing = null; showDialog = true }) { Text("+ محل جديد") }
            }
        }
        if (isBuyer) {
            Text("🔒 وضع المشتري: عرض فقط — لا يمكنك إضافة/حذف المحلات",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
        if (shops.isEmpty()) {
            EmptyState("لا توجد محلات بعد", "🏪")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shops) { shop ->
                    val count = products.count { it.shopId == shop.id }
                    com.tatbiqi.app.ui.motion.StaggerItem(index = shops.indexOf(shop)) {
                    Card(colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = com.tatbiqi.app.ui.theme.AppShapes.Card,
                        modifier = Modifier.fillMaxWidth().motionPress {
                            navigateTo(Views.SHOP_DETAIL, mapOf("shopId" to shop.id))
                        }) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            // أيقونة المحل بلونه (مطابق HTML)
                            Box(
                                Modifier
                                    .size(46.dp)
                                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                                    .background(com.tatbiqi.app.ui.theme.AppColors.GradBlue),
                                contentAlignment = androidx.compose.ui.Alignment.Center
                            ) { Text("🏪") }
                            androidx.compose.foundation.layout.Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(shop.name, style = MaterialTheme.typography.titleMedium, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                                Text("${count} صنف • ${shop.phone}", style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (auth.has("shops.manage")) {
                                TextButton(onClick = { editing = shop; showDialog = true }) { Text("تعديل") }
                                TextButton(onClick = { vm.deleteShop(shop.id) }) { Text("🗑", color = MaterialTheme.colorScheme.error) }
                            }
                        }
                    }
                    }
                }
            }
        }
    }

    if (showDialog) {
        ShopDialog(shop = editing, onDismiss = { showDialog = false }, onSave = { name, color, phone, note ->
            vm.saveShop(editing?.id, name, color, phone, note)
            showDialog = false
        })
    }
}

@Composable
fun ShopDialog(shop: Shop?, onDismiss: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf(shop?.name ?: "") }
    var phone by remember { mutableStateOf(shop?.phone ?: "") }
    var color by remember { mutableStateOf(shop?.color ?: "#2563EB") }
    var note by remember { mutableStateOf(shop?.note ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (shop == null) "إضافة محل" else "تعديل محل") },
        text = {
            Column {
                LabeledField(name, { name = it }, "اسم المحل")
                Spacer(Modifier.height(8.dp))
                LabeledField(phone, { phone = it }, "رقم الهاتف")
                Spacer(Modifier.height(8.dp))
                LabeledField(color, { color = it }, "اللون")
            }
        },
        confirmButton = {
            PrimaryButton("حفظ") { onSave(name, color, phone, note) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
