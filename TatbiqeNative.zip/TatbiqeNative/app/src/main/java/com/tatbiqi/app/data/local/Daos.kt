package com.tatbiqi.app.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.tatbiqi.app.data.model.Customer
import com.tatbiqi.app.data.model.Order
import com.tatbiqi.app.data.model.Product
import com.tatbiqi.app.data.model.Shop
import com.tatbiqi.app.data.model.User
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(user: User)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(users: List<User>)
    @Update suspend fun update(user: User)
    @Delete suspend fun delete(user: User)
    @Query("DELETE FROM users WHERE id = :id") suspend fun deleteById(id: String)
    @Query("SELECT * FROM users") suspend fun getAll(): List<User>
    @Query("SELECT * FROM users") fun observeAll(): Flow<List<User>>
    @Query("SELECT * FROM users WHERE id = :id") suspend fun getById(id: String): User?
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1") suspend fun getByUsername(username: String): User?
}

@Dao
interface ShopDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(shop: Shop)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(shops: List<Shop>)
    @Update suspend fun update(shop: Shop)
    @Delete suspend fun delete(shop: Shop)
    @Query("DELETE FROM shops WHERE id = :id") suspend fun deleteById(id: String)
    @Query("SELECT * FROM shops WHERE isDeleted = 0 ORDER BY name") fun observeAll(): Flow<List<Shop>>
    @Query("SELECT * FROM shops WHERE isDeleted = 0") suspend fun getAll(): List<Shop>
    @Query("SELECT * FROM shops WHERE id = :id") suspend fun getById(id: String): Shop?
}

@Dao
interface ProductDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(product: Product)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(products: List<Product>)
    @Update suspend fun update(product: Product)
    @Delete suspend fun delete(product: Product)
    @Query("DELETE FROM products WHERE id = :id") suspend fun deleteById(id: String)
    @Query("SELECT * FROM products WHERE isDeleted = 0 ORDER BY name") fun observeAll(): Flow<List<Product>>
    @Query("SELECT * FROM products WHERE isDeleted = 0") suspend fun getAll(): List<Product>
    @Query("SELECT * FROM products WHERE id = :id") suspend fun getById(id: String): Product?
    @Query("SELECT * FROM products WHERE isDeleted = 0 AND shopId = :shopId") suspend fun getByShop(shopId: String): List<Product>
}

@Dao
interface CustomerDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(customer: Customer)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(customers: List<Customer>)
    @Update suspend fun update(customer: Customer)
    @Delete suspend fun delete(customer: Customer)
    @Query("DELETE FROM customers WHERE id = :id") suspend fun deleteById(id: String)
    @Query("SELECT * FROM customers WHERE isDeleted = 0 ORDER BY name") fun observeAll(): Flow<List<Customer>>
    @Query("SELECT * FROM customers WHERE isDeleted = 0") suspend fun getAll(): List<Customer>
    @Query("SELECT * FROM customers WHERE id = :id") suspend fun getById(id: String): Customer?
}

@Dao
interface OrderDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(order: Order)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(orders: List<Order>)
    @Update suspend fun update(order: Order)
    @Delete suspend fun delete(order: Order)
    @Query("DELETE FROM orders WHERE id = :id") suspend fun deleteById(id: String)
    @Query("SELECT * FROM orders WHERE isDeleted = 0 ORDER BY createdAt DESC") fun observeAll(): Flow<List<Order>>
    @Query("SELECT * FROM orders WHERE isDeleted = 0") suspend fun getAll(): List<Order>
    @Query("SELECT * FROM orders WHERE id = :id") suspend fun getById(id: String): Order?
    @Query("SELECT * FROM orders WHERE isDeleted = 0 AND status = :status")
    fun observeByStatus(status: String): Flow<List<Order>>
}
