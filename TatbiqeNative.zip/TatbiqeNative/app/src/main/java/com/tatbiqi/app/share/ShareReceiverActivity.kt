package com.tatbiqi.app.share

import android.content.ContentResolver
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.ui.theme.TatbiqeTheme
import java.io.InputStream

/**
 * يستقبل الصور المُرادة من تطبيقات خارجية (مثل واتساب) عبر Intent SEND —
 * محاكاة checkSharedOnLoad + handleSharedImage في HTML.
 */
class ShareReceiverActivity : ComponentActivity() {

    private var bitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val action = intent?.action
        val type = intent?.type

        if (Intent.ACTION_SEND == action && type?.startsWith("image/") == true) {
            val imageUri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            imageUri?.let { bitmap = loadBitmap(it) }
        } else if (Intent.ACTION_SEND_MULTIPLE == action && type?.startsWith("image/") == true) {
            val uris = intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
            bitmap = uris?.firstOrNull()?.let { loadBitmap(it) }
        }

        setContent {
            TatbiqeTheme {
                SharePreview(
                    image = bitmap,
                    onAddToOrder = {
                        // 🔧 مشاركة صورة → تُفتح شاشة الطلب مع صورة + اختيار زبون ومحل
                        val app = application as com.tatbiqi.app.TatbiqeApp
                        bitmap?.let { bmp ->
                            val dataUrl = bitmapToDataUrl(bmp)
                            app.repository.storeSharedImage(dataUrl, "shared.jpg")
                        }
                        // فتح نموذج طلب جديد بالصورة المخزّنة
                        startActivity(Intent(this, com.tatbiqi.app.MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                        })
                        finish()
                    },
                    onDismiss = { finish() }
                )
            }
        }
    }

    private fun bitmapToDataUrl(bmp: Bitmap): String {
        val out = java.io.ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return "data:image/jpeg;base64," + android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)
    }

    private fun loadBitmap(uri: Uri): Bitmap? = try {
        val stream: InputStream? = contentResolver.openInputStream(uri)
        stream?.use { BitmapFactory.decodeStream(it) }
    } catch (e: Exception) { null }
}

@Composable
private fun SharePreview(image: Bitmap?, onAddToOrder: () -> Unit, onDismiss: () -> Unit) {
    val bmp = remember(image) { image }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize().weight(1f),
                contentScale = ContentScale.Fit
            )
        } else {
            Text("تعذّر قراءة الصورة", style = MaterialTheme.typography.bodyLarge)
        }
        TextButton(onClick = onAddToOrder) { Text("إضافة الصورة إلى طلب") }
        TextButton(onClick = onDismiss) { Text("إغلاق") }
    }
}
