package com.tatbiqi.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * نماذج البيانات — مطابقة تماماً لنموذج بيانات ملف HTML الأصلي:
 *   DB = { shops[], products[], customers[], orders[], users[] }
 * كل كيان يعمل كمخزن محلي (Room) ويمُيَّز بمعرّف workspaceId للمزامنة السحابية.
 */

@Entity(tableName = "users")
data class User(
    @PrimaryKey val id: String,
    val username: String = "",
    val password: String = "",
    val name: String = "",
    val role: String = "buyer",          // owner | buyer | delivery | manager | seller | viewer
    val isActive: Boolean = true,
    val workspaceId: String = "workspace-001",
    val cloud: Boolean = false,
    val permissions: Map<String, Boolean> = emptyMap(),
    val updatedAt: Long = 0L
) {
    companion object {
        fun defaultPermissions(): Map<String, Boolean> = mapOf(
            "orders.create" to true, "orders.edit" to true, "orders.delete" to true,
            "orders.changeStatus" to true, "orders.viewAll" to true,
            "segments.confirm" to true,
            "shops.manage" to true, "shops.view" to true,
            "products.manage" to true,
            "customers.manage" to true, "customers.view" to true, "customers.csv" to true,
            "delivery.view" to true, "delivery.confirm" to true,
            "debts.view" to true,
            "reports.view" to true, "reports.profit" to true,
            "users.manage" to true
        )
        fun buyerPermissions(): Map<String, Boolean> = mapOf(
            "orders.viewAssigned" to true, "segments.confirm" to true,
            "shops.view" to true, "customers.view" to true, "delivery.view" to true
        )
    }
    fun has(perm: String): Boolean = permissions[perm] ?: false
}

@Entity(tableName = "shops")
data class Shop(
    @PrimaryKey val id: String,
    val name: String = "",
    val color: String = "#2563EB",
    val phone: String = "",
    val note: String = "",
    val workspaceId: String = "workspace-001",
    val isDeleted: Boolean = false,
    val updatedAt: Long = 0L
)

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val id: String,
    val name: String = "",
    val price: Int = 0,
    val buyPrice: Int = 0,
    val shopId: String = "",
    val category: String = "",
    val stock: Int = 0,
    val imageUrl: String = "",
    val workspaceId: String = "workspace-001",
    val isDeleted: Boolean = false,
    val updatedAt: Long = 0L
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey val id: String,
    val name: String = "",
    val phone: String = "",
    val note: String = "",
    val totalDebt: Int = 0,          // الدين المُخزّن — يُحدَّث مع كل عملية (مطابق HTML)
    val workspaceId: String = "workspace-001",
    val isDeleted: Boolean = false,
    val updatedAt: Long = 0L
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey val id: String,
    val status: String = "new",          // new | delivering | delivered | cancelled
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val segmentsJson: String = "[]",     // segments[].items[] — مخزّنة JSON للتوسع
    val totalAmount: Int = 0,
    val paidAmount: Int = 0,
    val remainingAmount: Int = 0,
    val costAmount: Int = 0,
    val currency: String = "ر.ي",
    val type: String = "cash",           // cash | credit
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
    val workspaceId: String = "workspace-001",
    val isDeleted: Boolean = false
)

/** شريحة (segment) داخل الطلب — مجموعة أصناف من محل واحد. */
data class Segment(
    val shopId: String = "",
    val shopName: String = "",
    val status: String = "pending",      // pending | purchased | unavailable | confirmed
    val items: List<OrderItem> = emptyList(),
    val costAmount: Int = 0,
    val cash: Int = 0,                   // المبلغ المدفوع فعلياً للمحل
    val paid: Boolean = false,
    val paidActualAmount: Int = 0        // مبلغ الشراء الفعلي (مطابق HTML)
)

/** صنف داخل شريحة. */
data class OrderItem(
    val name: String = "",
    val quantity: Int = 0,
    val buyPrice: Int = 0,               // سعر الشراء من المحل
    val price: Int = 0,                  // سعر البيع للزبون
    val size: String = "",
    val color: String = "",
    val imageUrl: String = ""
)

/** ترميز قائمة الشرائح إلى JSON بسيط لاستخدامه خارج الـ TypeConverter (مثلاً في ViewModel). */
fun encodeSegments(segments: List<Segment>): String {
    val sb = StringBuilder("[")
    segments.forEachIndexed { si, s ->
        if (si > 0) sb.append(",")
        sb.append("{\"shopId\":\"${s.shopId}\",\"shopName\":\"${s.shopName}\"," +
                "\"status\":\"${s.status}\",\"costAmount\":${s.costAmount}," +
                "\"cash\":${s.cash},\"paid\":${s.paid},\"paidActualAmount\":${s.paidActualAmount},\"items\":[")
        s.items.forEachIndexed { ii, it ->
            if (ii > 0) sb.append(",")
            sb.append("{\"name\":\"${it.name}\",\"quantity\":${it.quantity}," +
                    "\"buyPrice\":${it.buyPrice},\"price\":${it.price}," +
                    "\"size\":\"${it.size}\",\"color\":\"${it.color}\",\"imageUrl\":\"${it.imageUrl}\"}")
        }
        sb.append("]}")
    }
    sb.append("]")
    return sb.toString()
}
