package com.tatbiqi.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tatbiqi.app.TatbiqeApp
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.authViewModelFactory
import com.tatbiqi.app.ui.screens.login.LoginScreen

/**
 * الجذر الرئيسي — محاكاة render() في HTML:
 * إذا لم يسجّل → شاشة الدخول، وإلا → التطبيق (MainScreen).
 */
@Composable
fun TatbiqeNavHost(app: TatbiqeApp) {
    val authViewModel: AuthViewModel = viewModel(
        factory = authViewModelFactory(app.repository, app.session)
    )
    val authState by authViewModel.state.collectAsState()

    if (!authState.isLoggedIn || authState.currentUser == null) {
        LoginScreen(authViewModel, onLoggedIn = {})
    } else {
        MainScreen(
            app = app,
            authViewModel = authViewModel,
            currentUser = authState.currentUser,
            onLogout = { authViewModel.logout() }
        )
    }
}
