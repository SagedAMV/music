package com.tatbiqi.app.data.remote

import android.net.Uri
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import com.tatbiqi.app.data.model.Customer
import com.tatbiqi.app.data.model.Order
import com.tatbiqi.app.data.model.Product
import com.tatbiqi.app.data.model.Shop
import com.tatbiqi.app.data.model.User
import com.tatbiqi.app.data.repository.AppRepository
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.tasks.await

/**
 * محرك المزامنة السحابية — محاكاة منطق _syncDiffItems + queue في ملف HTML.
 *
 * القاعدة: يعمل أوفلاين (Room هو مصدر الحقيقة المحلي)، وعند التوفر يدفع
 * كل سطر مُحدَّث إلى Firestore ويسحب ما تغيّر سحابياً (last-write-wins على updatedAt).
 */
class SyncManager(
    private val repo: AppRepository,
    private val workspaceId: String = "workspace-001"
) {
    // 🔧 Firebase يُهيّأ كسولاً (lazy) — لا يُستدعى إلا عند استخدام المزامنة فعلياً.
    // هذا يمنع كراش الإطلاق عند غياب تهيئة Firebase (النسخة بدون google-services.json).
    private val isFirebaseReady: Boolean by lazy {
        try {
            com.google.firebase.FirebaseApp.getInstance() != null
        } catch (e: Throwable) { false }
    }
    private val db: FirebaseFirestore? by lazy {
        if (isFirebaseReady) FirebaseFirestore.getInstance() else null
    }
    private val storage: FirebaseStorage? by lazy {
        if (isFirebaseReady) FirebaseStorage.getInstance() else null
    }

    /**
     * ضغط صورة محلية ورفعها إلى Firebase Storage ثم إعادة رابط التنزيل.
     * محاكاة _processImagesForCloud + رفع storage في HTML.
     */
    suspend fun uploadImage(context: android.content.Context, uri: Uri): String? = try {
        val storage = storage ?: return null
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        val compressed = ImageCompressor.compress(bytes)
        val ref = storage.reference.child("images/img_${System.currentTimeMillis()}.jpg")
        ref.putBytes(compressed).await()
        ref.downloadUrl.await().toString()
    } catch (e: Exception) { Log.e("Sync", "uploadImage failed", e); null }

    suspend fun pushAll() {
        val db = db ?: run { Log.w("Sync", "Firebase غير مهيأ — تخطي الرفع"); return }
        val w = workspaceId
        db.collection("users").whereEqualTo("workspaceId", w).get().await() // ensure exists

        for (it in repo.getAllUsers()) push("users", it.id, userMap(it))
        for (it in repo.getAllShops()) push("shops", it.id, shopMap(it))
        for (it in repo.getAllOrders()) push("orders", it.id, orderMap(it))
        for (it in repo.getAllCustomers()) push("customers", it.id, customerMap(it))
        for (it in repo.getAllProducts()) push("products", it.id, productMap(it))
    }

    suspend fun pullAll() {
        if (db == null) { Log.w("Sync", "Firebase غير مهيأ — تخطي السحب"); return }
        pull("users") { doc ->
            val u = doc.toObject(User::class.java)
            u?.let { repo.upsertUser(it) }
        }
        pull("shops") { doc ->
            val s = doc.toObject(Shop::class.java)
            s?.let { repo.upsertShop(it) }
        }
        pull("customers") { doc ->
            val c = doc.toObject(Customer::class.java)
            c?.let { repo.upsertCustomer(it) }
        }
        pull("orders") { doc ->
            val o = doc.toObject(Order::class.java)
            o?.let { repo.upsertOrder(it) }
        }
        pull("products") { doc ->
            val p = doc.toObject(Product::class.java)
            p?.let { repo.upsertProduct(it) }
        }
    }

    private suspend fun push(collection: String, id: String, data: Map<String, Any?>) {
        val db = db ?: return
        try {
            db.collection(collection).document(id)
                .set(data, SetOptions.merge()).await()
        } catch (e: Exception) {
            Log.e("Sync", "push $collection/$id failed", e)
        }
    }

    private suspend fun pull(collection: String, onDoc: suspend (com.google.firebase.firestore.DocumentSnapshot) -> Unit) {
        val db = db ?: return
        try {
            val snap = db.collection(collection)
                .whereEqualTo("workspaceId", workspaceId)
                .get().await()
            for (d in snap.documents) {
                val ts = d.getLong("updatedAt") ?: 0L
                // last-write-wins: السطر الأحدث تحديثاً يربح
                val local = localUpdatedAt(collection, d.id)
                if (ts >= local) onDoc(d)
            }
        } catch (e: Exception) {
            Log.e("Sync", "pull $collection failed", e)
        }
    }

    private suspend fun localUpdatedAt(collection: String, id: String): Long =
        when (collection) {
            "users" -> repo.getUser(id)?.updatedAt ?: 0L
            "shops" -> repo.getShop(id)?.updatedAt ?: 0L
            "customers" -> repo.getCustomer(id)?.updatedAt ?: 0L
            "orders" -> repo.getOrder(id)?.updatedAt ?: 0L
            "products" -> repo.getProduct(id)?.updatedAt ?: 0L
            else -> 0L
        }

    // ---- Map to Firestore ----
    private fun userMap(u: User) = mapOf(
        "id" to u.id, "username" to u.username, "password" to u.password,
        "name" to u.name, "role" to u.role, "isActive" to u.isActive,
        "workspaceId" to u.workspaceId, "permissions" to u.permissions,
        "updatedAt" to System.currentTimeMillis()
    )
    private fun shopMap(s: Shop) = mapOf(
        "id" to s.id, "name" to s.name, "color" to s.color, "phone" to s.phone,
        "note" to s.note, "workspaceId" to s.workspaceId,
        "updatedAt" to System.currentTimeMillis()
    )
    private fun productMap(p: Product) = mapOf(
        "id" to p.id, "name" to p.name, "price" to p.price, "buyPrice" to p.buyPrice,
        "shopId" to p.shopId, "category" to p.category, "stock" to p.stock,
        "imageUrl" to p.imageUrl, "workspaceId" to p.workspaceId,
        "updatedAt" to System.currentTimeMillis()
    )
    private fun customerMap(c: Customer) = mapOf(
        "id" to c.id, "name" to c.name, "phone" to c.phone, "note" to c.note,
        "workspaceId" to c.workspaceId, "updatedAt" to System.currentTimeMillis()
    )
    private fun orderMap(o: Order) = mapOf(
        "id" to o.id, "status" to o.status, "customerId" to o.customerId,
        "customerName" to o.customerName, "customerPhone" to o.customerPhone,
        "segmentsJson" to o.segmentsJson, "totalAmount" to o.totalAmount,
        "paidAmount" to o.paidAmount, "remainingAmount" to o.remainingAmount,
        "costAmount" to o.costAmount, "currency" to o.currency, "type" to o.type,
        "createdAt" to o.createdAt, "workspaceId" to o.workspaceId,
        "updatedAt" to System.currentTimeMillis()
    )
}
