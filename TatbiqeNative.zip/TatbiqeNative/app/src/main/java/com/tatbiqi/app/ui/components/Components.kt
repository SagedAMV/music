package com.tatbiqi.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.ui.theme.AppColors
import com.tatbiqi.app.ui.theme.AppShapes
import com.tatbiqi.app.ui.motion.motionPress

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScaffold(
    title: String,
    navigationIcon: @Composable () -> Unit = {},
    actions: @Composable () -> Unit = {},
    snackbarHostState: SnackbarHostState = SnackbarHostState(),
    content: @Composable () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.Bold) },
                navigationIcon = navigationIcon,
                actions = { actions() },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Box(Modifier.padding(padding)) { content() }
    }
}

@Composable
fun EmptyState(text: String, icon: String = "📦") {
    Column(
        modifier = Modifier.fillMaxWidth().padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        com.tatbiqi.app.ui.motion.FloatingIcon(icon)
        Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun LoadingState() {
    Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

@Composable
fun LabeledField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String = "",
    isNumber: Boolean = false,
    singleLine: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = { Text(placeholder) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = singleLine,
        keyboardOptions = if (isNumber)
            androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
        else androidx.compose.foundation.text.KeyboardOptions()
    )
}

/** زر رئيسي متدرج (مطابق btn-primary في HTML). */
@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(containerColor = AppColors.Blue, disabledContainerColor = AppColors.Muted),
        shape = AppShapes.Medium
    ) { Text(text, fontWeight = FontWeight.Bold, color = Color.White) }
}

/** زر أخضر (مطابق btn-green في HTML). */
@Composable
fun GreenButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = AppColors.Green),
        shape = AppShapes.Medium
    ) { Text(text, fontWeight = FontWeight.Bold, color = Color.White) }
}

/** زر شبح (مطابق btn-ghost). */
@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(
            containerColor = AppColors.Card,
            contentColor = AppColors.Text
        ),
        shape = AppShapes.Medium,
        border = androidx.compose.foundation.BorderStroke(1.dp, AppColors.Border)
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

/** بطاقة غنية (مطابقة .card في HTML) مع ظل وزوايا. */
@Composable
fun RichCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val shape = AppShapes.Card
    val base = Modifier
        .shadow(elevation = 2.dp, shape = shape, ambientColor = Color(0x0F0F172A), spotColor = Color(0x0F0F172A))
        .clip(shape)
        .background(MaterialTheme.colorScheme.surface)
        .border(1.dp, MaterialTheme.colorScheme.outline, shape)
    val mod = if (onClick != null) base.motionPress(onClick) else base
    Box(mod.padding(16.dp)) { content() }
}

/** شارة دائرية (مطابقة .badge في HTML). */
@Composable
fun Pill(
    text: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(AppShapes.Pill)
            .background(color)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
    }
}

/** شارة حالة الطلب — مطابقة statusBadge في HTML. */
@Composable
fun StatusBadge(status: String) {
    val (label, color) = when (status) {
        "new" -> "جديد" to AppColors.Blue
        "purchasing" -> "قيد الشراء" to AppColors.Amber
        "purchased" -> "تم الشراء" to AppColors.Purple
        "unavailable" -> "غير متوفر" to AppColors.Red
        "delivering" -> "قيد التسليم" to AppColors.Orange
        "delivered" -> "تم التسليم" to AppColors.Green
        "cancelled" -> "ملغي" to AppColors.Red
        else -> status to AppColors.Muted
    }
    Pill(label, color)
}

/** عنوان صفحة (مطابق .page-title). */
@Composable
fun PageTitle(text: String) {
    Text(text, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
}

/** عنوان فرعي (مطابق .page-subtitle). */
@Composable
fun PageSubtitle(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** شريط تقدم (مطابق .progress-bar في HTML). */
@Composable
fun ProgressBar(progress: Float, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0xFFE2E8F0))
            .padding(vertical = 0.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .padding(vertical = 0.dp)
                .background(color)
        ) { }
    }
}

/** بطاقة إحصائية متدرجة (مطابقة .stat-card في HTML) مع عدّاد متحرك. */
@Composable
fun StatCard(label: String, value: String, gradient: Brush, icon: String) {
    Card(
        modifier = Modifier.fillMaxWidth().shadow(3.dp, AppShapes.Card, ambientColor = Color(0x260F172A)),
        shape = AppShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(gradient)
                .padding(18.dp)
        ) {
            Column {
                Text(icon, style = MaterialTheme.typography.headlineMedium)
                AnimatedCount(value, Color.White)
                Text(label, style = MaterialTheme.typography.labelMedium, color = Color.White)
            }
        }
    }
}

@Composable
fun AnimatedCount(value: String, color: Color) {
    val scale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.spring(
            dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy,
            stiffness = androidx.compose.animation.core.Spring.StiffnessLow
        )
    )
    Text(
        value,
        style = MaterialTheme.typography.headlineMedium,
        color = color,
        modifier = Modifier.graphicsLayer { scaleX = scale; scaleY = scale }
    )
}
