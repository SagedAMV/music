package com.tatbiqi.app.ui.screens.reports

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import com.tatbiqi.app.ui.theme.AppColors
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.ui.components.EmptyState
import com.tatbiqi.app.ui.components.StatCard
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel

/**
 * التقارير — محتوى تبويب reports (مطابق renderReports في HTML).
 */
@Composable
fun ReportsScreen(
    vm: MainViewModel,
    auth: AuthViewModel
) {
    val orders by vm.orders.collectAsState()

    LazyColumn(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (!auth.has("reports.view")) {
            item { EmptyState("لا تملك صلاحية التقارير", "🔒") }
            return@LazyColumn
        }
        item { StatCard("إجمالي المبيعات (ر.ي)", vm.monthlySales().toString(), AppColors.GradBlue, "💰") }
        item { StatCard("الربح المتوقع (ر.ي)", vm.totalProfit().toString(), AppColors.GradGreen, "📈") }
        item { StatCard("إجمالي الديون (ر.ي)", vm.debtsTotal().toString(), AppColors.GradRed, "💳") }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(14.dp)) {
                    Text("توزيع الطلبات حسب الحالة", style = MaterialTheme.typography.titleSmall)
                    Text("جديد: ${orders.count { it.status == "new" }}", style = MaterialTheme.typography.bodyMedium)
                    Text("قيد الشراء: ${orders.count { it.status == "purchasing" }}", style = MaterialTheme.typography.bodyMedium)
                    Text("قيد التسليم: ${orders.count { it.status == "delivering" }}", style = MaterialTheme.typography.bodyMedium)
                    Text("تم التسليم: ${orders.count { it.status == "delivered" }}", style = MaterialTheme.typography.bodyMedium)
                    Text("ملغي: ${orders.count { it.status == "cancelled" }}", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
