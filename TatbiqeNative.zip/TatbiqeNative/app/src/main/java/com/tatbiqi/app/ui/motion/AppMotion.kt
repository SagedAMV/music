package com.tatbiqi.app.ui.motion

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer

/**
 * نظام الحركة الموحد — محاكاة أنيميشن HTML (slideUp, fadeIn, pulse, shimmer, float, wiggle, countPop)
 * وتحسينه ليكون عصبرياً وناعماً عبر Spring + Keyframes.
 *
 * المبدأ: كل الحركات تُدار من نقطة واحدة (Tokens) لضمان الاتساق.
 */
object AppMotion {

    // ==== المدد (Timing) ====
    const val FAST = 180
    const val NORMAL = 260
    const val SLOW = 450
    const val SPRING_SOFT = 0.82f

    // ==== منحنيات ====
    val standard = tween<Float>(NORMAL, easing = FastOutSlowInEasing)
    val springSoft = spring<Float>(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
    val springGentle = spring<Float>(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow)

    /** دخول الصفحة — محاكاة slideUp + fadeIn (page-enter في HTML). */
    @Composable
    fun pageEnter(): State<Float> =
        animateFloatAsState(1f, tween(SLOW, easing = FastOutSlowInEasing))

    /** نبضة مستمرة — محاكاة pulse (تحميل/مزامنة). */
    @Composable
    fun rememberPulse(): State<Float> {
        val t = rememberInfiniteTransition(label = "pulse")
        return t.animateFloat(
            initialValue = 1f, targetValue = 1.12f,
            animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
            label = "pulseScale"
        )
    }

    /** تمايل مستمر — محاكاة float (عناصر تطفو). */
    @Composable
    fun rememberFloat(): State<Float> {
        val t = rememberInfiniteTransition(label = "float")
        return t.animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1500), RepeatMode.Reverse),
            label = "float"
        )
    }

    /** دوران مستمر — محاكاة spin (مزامنة). */
    @Composable
    fun rememberSpin(): State<Float> {
        val t = rememberInfiniteTransition(label = "spin")
        return t.animateFloat(
            initialValue = 0f, targetValue = 360f,
            animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Restart),
            label = "spin"
        )
    }

    /** اهتزاز — محاكاة wiggle (تنبيه). */
    @Composable
    fun rememberWiggle(): State<Float> {
        val t = rememberInfiniteTransition(label = "wiggle")
        return t.animateFloat(
            initialValue = -1f, targetValue = 1f,
            animationSpec = infiniteRepeatable(
                keyframes { durationMillis = 600; -1f at 0; 0f at 150; 1f at 300; 0f at 450 },
                RepeatMode.Restart
            ),
            label = "wiggleAngle"
        )
    }

    /** ظهور عدّاد — محاكاة countPop (عند تغيّر القيمة). */
    @Composable
    fun rememberCountPop(key: Any?): State<Float> {
        val t = rememberInfiniteTransition(label = "countPop_$key")
        return t.animateFloat(
            initialValue = 1f, targetValue = 1f,
            animationSpec = infiniteRepeatable(
                keyframes { durationMillis = 400; 0.85f at 0; 1.08f at 150; 1f at 400 },
                RepeatMode.Restart
            ),
            label = "countPop"
        )
    }
}

/** معدّل للدخول الناعم (slideUp + fadeIn) — يطبَّق على الحاوية. */
fun Modifier.motionPageEnter(progress: Float): Modifier =
    this.graphicsLayer {
        val p = progress
        translationY = (1f - p) * 24f
        scaleX = 0.96f + 0.04f * p
        scaleY = 0.96f + 0.04f * p
        alpha = p
        transformOrigin = TransformOrigin(0.5f, 0.5f)
    }
