package com.tatbiqi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Surface
import com.tatbiqi.app.ui.navigation.TatbiqeNavHost
import com.tatbiqi.app.ui.theme.TatbiqeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TatbiqeTheme {
                Surface {
                    TatbiqeNavHost(app = application as TatbiqeApp)
                }
            }
        }
    }
}
