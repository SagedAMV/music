package com.tatbiqi.app

import android.app.Application
import com.tatbiqi.app.data.local.AppDatabase
import com.tatbiqi.app.data.repository.AppRepository
import com.tatbiqi.app.data.remote.SyncManager
import com.tatbiqi.app.data.session.SessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * حاوية التطبيق (Service Locator بسيط) — عقدة الحقيقة الواحدة لربط النظام كله.
 */
class TatbiqeApp : Application() {
    lateinit var repository: AppRepository
    lateinit var syncManager: SyncManager
    lateinit var session: SessionManager

    override fun onCreate() {
        super.onCreate()
        session = SessionManager(this)
        try {
            // Room يفتح قاعدة البيانات كسولاً (lazy) — لا يفتح فعلياً حتى أول استعلام.
            // fallbackToDestructiveMigration يمنع الكراش عند تغيّر مخطط DB بين النسخ.
            val db = AppDatabase.get(this)
            repository = AppRepository(db)
            syncManager = SyncManager(repository)
            // زرع المستخدم الافتراضي في الخلفية (لا يمس الخيط الرئيسي)
            CoroutineScope(Dispatchers.IO).launch { repository.seedIfEmpty() }
        } catch (e: Throwable) {
            android.util.Log.e("TatbiqeApp", "تهيئة التطبيق فشلت", e)
        }
    }
}
