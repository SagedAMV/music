package com.tatbiqi.app.data.session

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.tatbiqi.app.data.model.User
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "session")

/**
 * إدارة الجلسة والإعدادات — محاكاة saveSession / toggleTheme / tatbiqi-useCloud في HTML.
 */
class SessionManager(private val context: Context) {

    private object Keys {
        val USER_ID = stringPreferencesKey("userId")
        val THEME = booleanPreferencesKey("dark_theme")
        val USE_CLOUD = booleanPreferencesKey("use_cloud")
        val WORKSPACE = stringPreferencesKey("workspace")
    }

    val currentUserId: Flow<String?> = context.dataStore.data
        .map { it[Keys.USER_ID] }

    val isDarkTheme: Flow<Boolean> = context.dataStore.data
        .map { it[Keys.THEME] ?: false }

    val useCloud: Flow<Boolean> = context.dataStore.data
        .map { it[Keys.USE_CLOUD] ?: true }

    val workspaceId: Flow<String> = context.dataStore.data
        .map { it[Keys.WORKSPACE] ?: "workspace-001" }

    suspend fun saveSession(user: User, useCloud: Boolean) {
        context.dataStore.edit {
            it[Keys.USER_ID] = user.id
            it[Keys.WORKSPACE] = user.workspaceId
            it[Keys.USE_CLOUD] = useCloud
        }
    }

    suspend fun setTheme(dark: Boolean) {
        context.dataStore.edit { it[Keys.THEME] = dark }
    }

    suspend fun clearSession() {
        context.dataStore.edit { it.remove(Keys.USER_ID) }
    }

    suspend fun isLoggedIn(): Boolean = currentUserId.first() != null
}
