package com.tatbiqi.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.tatbiqi.app.data.model.Customer
import com.tatbiqi.app.data.model.Order
import com.tatbiqi.app.data.model.OrderItem
import com.tatbiqi.app.data.model.Product
import com.tatbiqi.app.data.model.Segment
import com.tatbiqi.app.data.model.Shop
import com.tatbiqi.app.data.model.User
import org.json.JSONArray
import org.json.JSONObject

class Converters {
    @TypeConverter
    fun fromPermissions(map: Map<String, Boolean>?): String? =
        map?.let { JSONObject(it).toString() }

    @TypeConverter
    fun toPermissions(json: String?): Map<String, Boolean>? {
        if (json.isNullOrBlank()) return null
        val out = mutableMapOf<String, Boolean>()
        val obj = JSONObject(json)
        val it = obj.keys()
        while (it.hasNext()) { val k = it.next(); out[k] = obj.optBoolean(k) }
        return out
    }

    @TypeConverter
    fun fromSegments(list: List<Segment>?): String =
        list?.let { buildJsonArray(it).toString() } ?: "[]"

    @TypeConverter
    fun toSegments(json: String?): List<Segment> {
        if (json.isNullOrBlank()) return emptyList()
        val arr = JSONArray(json)
        val out = mutableListOf<Segment>()
        for (i in 0 until arr.length()) out.add(parseSegment(arr.getJSONObject(i)))
        return out
    }

    private fun buildJsonArray(segments: List<Segment>): JSONArray {
        val arr = JSONArray()
        segments.forEach { s ->
            val items = JSONArray()
            s.items.forEach { it ->
                items.put(JSONObject().apply {
                    put("name", it.name); put("quantity", it.quantity)
                    put("buyPrice", it.buyPrice); put("price", it.price)
                    put("size", it.size); put("color", it.color); put("imageUrl", it.imageUrl)
                })
            }
            arr.put(JSONObject().apply {
                put("shopId", s.shopId); put("shopName", s.shopName)
                put("status", s.status); put("items", items)
                put("costAmount", s.costAmount); put("cash", s.cash); put("paid", s.paid)
                put("paidActualAmount", s.paidActualAmount)
            })
        }
        return arr
    }

    private fun parseSegment(o: JSONObject): Segment {
        val itemsArr = o.optJSONArray("items") ?: JSONArray()
        val items = mutableListOf<OrderItem>()
        for (i in 0 until itemsArr.length()) {
            val io = itemsArr.getJSONObject(i)
            items.add(OrderItem(
                name = io.optString("name"), quantity = io.optInt("quantity"),
                buyPrice = io.optInt("buyPrice"), price = io.optInt("price"),
                size = io.optString("size"), color = io.optString("color"),
                imageUrl = io.optString("imageUrl")
            ))
        }
        return Segment(
            shopId = o.optString("shopId"), shopName = o.optString("shopName"),
            status = o.optString("status", "pending"), items = items,
            costAmount = o.optInt("costAmount"), cash = o.optInt("cash"),
            paid = o.optBoolean("paid"), paidActualAmount = o.optInt("paidActualAmount")
        )
    }
}

@Database(
    entities = [User::class, Shop::class, Product::class, Customer::class, Order::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun shopDao(): ShopDao
    abstract fun productDao(): ProductDao
    abstract fun customerDao(): CustomerDao
    abstract fun orderDao(): OrderDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, AppDatabase::class.java, "tatbiqi.db"
                )
                .fallbackToDestructiveMigration()   // 🔧 يمنع الكراش عند تغيّر مخطط DB بين النسخ
                .setJournalMode(RoomDatabase.JournalMode.TRUNCATE)
                .build().also { INSTANCE = it }
            }
    }
}
