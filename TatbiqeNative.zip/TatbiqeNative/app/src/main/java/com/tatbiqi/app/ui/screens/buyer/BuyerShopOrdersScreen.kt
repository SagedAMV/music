package com.tatbiqi.app.ui.screens.buyer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.data.model.Order
import com.tatbiqi.app.data.model.Segment
import com.tatbiqi.app.ui.components.AppScaffold
import com.tatbiqi.app.ui.components.EmptyState
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel
import com.tatbiqi.app.ui.screens.segmentFrom
import kotlinx.coroutines.launch

/**
 * تفاصيل مهام محل واحد للمشتري — محاكاة renderBuyerShopOrders + buyerConfirm.
 * يعرض الشرائح المعلقة لهذا المحل مع الأصناف، ويتيح تأكيد الشراء (بمبلغ) أو تعليم غير متوفر.
 */
@Composable
fun BuyerShopOrdersScreen(
    vm: MainViewModel,
    auth: AuthViewModel,
    shopId: String,
    onBack: () -> Unit
) {
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val shops by vm.shops.collectAsState()
    val orders by vm.orders.collectAsState()
    val shop = shops.find { it.id == shopId }
    val canConfirm = auth.has("segments.confirm")

    // الشرائح المعلقة لهذا المحل من الطلبات قيد الشراء فقط
    val segments = orders
        .filter { it.status == "purchasing" }
        .flatMap { o -> segmentFrom(o.segmentsJson)
            .filter { it.shopId == shopId && it.status == "pending" }
            .map { seg -> o to seg } }

    AppScaffold(
        title = shop?.name ?: "المحل",
        navigationIcon = {
            TextButton(onClick = onBack) { Text("← المحلات") }
        },
        snackbarHostState = snackbar
    ) {
        LazyColumn(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { CashBanner(cash = vm.buyerPendingCash(), pending = vm.buyerPendingSegCount()) }
            item {
                if (!canConfirm) {
                    Text("🔒 عرض فقط — ليس لديك صلاحية التأكيد. راجع المالك.",
                        color = MaterialTheme.colorScheme.error)
                }
            }
            if (segments.isEmpty()) {
                item { EmptyState("انتهت طلبات هذا المحل ✅", "✅") }
            } else {
                items(segments.size) { i ->
                    val (order, seg) = segments[i]
                    BuyerSegmentCard(
                        order = order, seg = seg,
                        cost = vm.segmentCost(seg), sell = vm.segmentSell(seg),
                        canConfirm = canConfirm,
                        onConfirm = { status, paid ->
                            vm.confirmSegment(order.id, shopId, status, paid)
                            scope.launch { snackbar.showSnackbar("تم التحديث ✅") }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun BuyerSegmentCard(
    order: Order, seg: Segment, cost: Int, sell: Int,
    canConfirm: Boolean, onConfirm: (String, Int) -> Unit
) {
    var paid by remember { mutableStateOf(cost.toString()) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth()) {
                Text("👤 ${order.customerName}", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.weight(1f))
                Text("$cost ر.ي", style = MaterialTheme.typography.titleLarge, color = Color(0xFF10B981))
            }
            Text(order.customerPhone, style = MaterialTheme.typography.bodySmall)
            Text("تُدفع للمحل (سعر الشراء) • البيع للزبون: $sell ر.ي", style = MaterialTheme.typography.bodySmall)

            Spacer(Modifier.height(8.dp))
            // قائمة الأصناف
            seg.items.forEach { it ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text(it.name.ifEmpty { "صنف" }, modifier = Modifier.weight(1f))
                    Text("×${it.quantity}")
                }
                Row(Modifier.fillMaxWidth()) {
                    Text("بيع: ${it.price} • شراء: ${it.buyPrice}", style = MaterialTheme.typography.bodySmall)
                }
                if (it.size.isNotBlank() || it.color.isNotBlank()) {
                    Text("مقاس: ${it.size} • لون: ${it.color}", style = MaterialTheme.typography.bodySmall)
                }
            }

            if (canConfirm) {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = paid, onValueChange = { paid = it },
                    label = { Text("المبلغ المدفوع فعلياً (ر.ي)") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    androidx.compose.material3.Button(
                        onClick = { onConfirm("purchased", paid.toIntOrNull() ?: cost) },
                        modifier = Modifier.weight(1f)
                    ) { Text("✅ تم الشراء") }
                    androidx.compose.material3.OutlinedButton(
                        onClick = { onConfirm("unavailable", 0) },
                        modifier = Modifier.weight(1f)
                    ) { Text("⚠️ غير متوفر") }
                }
            }
        }
    }
}
