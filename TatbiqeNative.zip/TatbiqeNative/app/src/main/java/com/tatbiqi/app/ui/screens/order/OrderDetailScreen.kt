package com.tatbiqi.app.ui.screens.order

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.data.model.Order
import com.tatbiqi.app.data.model.Segment
import com.tatbiqi.app.ui.components.AppScaffold
import com.tatbiqi.app.ui.components.EmptyState
import com.tatbiqi.app.ui.components.PrimaryButton
import com.tatbiqi.app.ui.components.StatusBadge
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel
import com.tatbiqi.app.ui.screens.segmentFrom
import kotlinx.coroutines.launch

/**
 * تفاصيل الطلب — محاكاة renderOrderDetail في HTML.
 */
@Composable
fun OrderDetailScreen(
    vm: MainViewModel,
    auth: AuthViewModel,
    orderId: String,
    onBack: () -> Unit
) {
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val orders by vm.orders.collectAsState()
    val order = orders.find { it.id == orderId }
    val segments = order?.segmentsJson?.let { segmentFrom(it) } ?: emptyList()

    AppScaffold(
        title = "تفاصيل الطلب",
        navigationIcon = {
            TextButton(onClick = onBack) { Text("رجوع") }
        },
        snackbarHostState = snackbar
    ) {
        if (order == null) {
            EmptyState("الطلب غير موجود", "🔍")
        } else {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(order.customerName, style = MaterialTheme.typography.titleLarge)
                        Text(order.customerPhone, style = MaterialTheme.typography.bodyMedium)
                        StatusBadge(order.status)
                        Spacer(Modifier.height(8.dp))
                        Text("الإجمالي: ${order.totalAmount} ${order.currency}", style = MaterialTheme.typography.titleMedium)
                        Text("المدفوع: ${order.paidAmount} • المتبقي: ${order.remainingAmount}")
                        if (order.remainingAmount > 0) {
                            Text("نوع الدفع: آجل", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                segments.forEach { seg ->
                    SegmentDetailCard(seg)
                    Spacer(Modifier.height(8.dp))
                }
                // تغيير الحالة
                if (auth.has("orders.changeStatus")) {
                    Spacer(Modifier.height(8.dp))
                    StatusActions(vm, order) { status ->
                        vm.changeStatus(order.id, status)
                        scope.launch { snackbar.showSnackbar("تم تحديث الحالة ✅") }
                    }
                }
            }
        }
    }
}

@Composable
fun SegmentDetailCard(seg: Segment) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp)) {
            Text(seg.shopName.ifEmpty { "محل" }, style = MaterialTheme.typography.titleMedium)
            seg.items.forEach { it ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text(it.name.ifEmpty { "صنف" }, modifier = Modifier.weight(1f))
                    Text("×${it.quantity}")
                }
                Row(Modifier.fillMaxWidth()) {
                    Text("بيع: ${it.price} • شراء: ${it.buyPrice}", style = MaterialTheme.typography.bodySmall)
                }
                if (it.size.isNotBlank() || it.color.isNotBlank()) {
                    Text("مقاس: ${it.size} • لون: ${it.color}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun StatusActions(vm: MainViewModel, order: Order, onChange: (String) -> Unit) {
    Card {
        Column(Modifier.padding(12.dp)) {
            Text("تغيير الحالة", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("new" to "جديد", "delivering" to "تسليم", "delivered" to "تم", "cancelled" to "إلغاء")
                    .forEach { (s, label) ->
                        if (order.status != s) {
                            PrimaryButton(label, onClick = { onChange(s) }, modifier = Modifier.weight(1f))
                        }
                    }
            }
        }
    }
}
