package com.tatbiqi.app.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tatbiqi.app.data.model.Customer
import com.tatbiqi.app.data.model.Order
import com.tatbiqi.app.data.model.Product
import com.tatbiqi.app.data.model.Segment
import com.tatbiqi.app.data.model.Shop
import com.tatbiqi.app.data.model.User
import com.tatbiqi.app.data.repository.AppRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel مركزي للبيانات الحية — يجمع كل التدفقات (المهارة 13: Flow / StateFlow)
 * ويوفّر عمليات CRUD (المهارة 3 الخوارزمية).
 */
class MainViewModel(private val repo: AppRepository) : ViewModel() {

    val shops: StateFlow<List<Shop>> = repo.observeShops()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val products: StateFlow<List<Product>> = repo.observeProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val customers: StateFlow<List<Customer>> = repo.observeCustomers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val orders: StateFlow<List<Order>> = repo.observeOrders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val users: StateFlow<List<User>> = repo.observeUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _toast = MutableStateFlow<String?>(null)
    val toast: StateFlow<String?> = _toast.asStateFlow()

    fun showToast(msg: String) { _toast.value = msg }
    fun consumeToast() { _toast.value = null }

    // ---------- Shops ----------
    fun saveShop(id: String?, name: String, color: String, phone: String, note: String) {
        viewModelScope.launch {
            val shop = Shop(
                id = id ?: "s${System.currentTimeMillis()}",
                name = name, color = color, phone = phone, note = note,
                updatedAt = System.currentTimeMillis()
            )
            repo.upsertShop(shop)
        }
    }
    fun deleteShop(id: String) {
        viewModelScope.launch { repo.upsertShop(repo.getShop(id)?.copy(isDeleted = true, updatedAt = System.currentTimeMillis()) ?: return@launch) }
    }

    // ---------- Products ----------
    fun saveProduct(id: String?, name: String, price: Int, buyPrice: Int, shopId: String, category: String, stock: Int, imageUrl: String) {
        viewModelScope.launch {
            repo.upsertProduct(Product(
                id = id ?: "p${System.currentTimeMillis()}",
                name = name, price = price, buyPrice = buyPrice, shopId = shopId,
                category = category, stock = stock, imageUrl = imageUrl,
                updatedAt = System.currentTimeMillis()
            ))
        }
    }
    fun deleteProduct(id: String) {
        viewModelScope.launch { repo.upsertProduct(repo.getProduct(id)?.copy(isDeleted = true, updatedAt = System.currentTimeMillis()) ?: return@launch) }
    }

    // ---------- Customers ----------
    fun saveCustomer(id: String?, name: String, phone: String, note: String) {
        viewModelScope.launch {
            repo.upsertCustomer(Customer(
                id = id ?: "c${System.currentTimeMillis()}",
                name = name, phone = phone, note = note,
                updatedAt = System.currentTimeMillis()
            ))
        }
    }
    fun deleteCustomer(id: String) {
        viewModelScope.launch { repo.upsertCustomer(repo.getCustomer(id)?.copy(isDeleted = true, updatedAt = System.currentTimeMillis()) ?: return@launch) }
    }

    // ---------- Orders ----------
    /** حساب إجمالي الطلب من الشرائح — محاكاة total = segments.reduce في HTML. */
    fun computeTotals(segments: List<Segment>): Triple<Int, Int, Int> {
        val total = segments.sumOf { s -> s.items.sumOf { it.price * it.quantity } }
        val cost = segments.sumOf { s -> s.items.sumOf { it.buyPrice * it.quantity } }
        return Triple(total, cost, total - cost)
    }

    fun saveOrder(
        id: String?, customer: Customer?, segments: List<Segment>,
        status: String = "new", paidAmount: Int = 0
    ) {
        viewModelScope.launch {
            val (total, cost, _) = computeTotals(segments)
            val order = Order(
                id = id ?: "o${System.currentTimeMillis()}",
                status = status,
                customerId = customer?.id ?: "",
                customerName = customer?.name ?: "زبون نقدي",
                customerPhone = customer?.phone ?: "",
                segmentsJson = com.tatbiqi.app.data.model.encodeSegments(segments),
                totalAmount = total,
                paidAmount = paidAmount,
                remainingAmount = (total - paidAmount).coerceAtLeast(0),
                costAmount = cost,
                type = if (paidAmount >= total) "cash" else "credit",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            repo.upsertOrder(order)
        }
    }

    // ---------- Buyer tasks (مهام المشتري) ----------
    /** الطلبات النشطة للشراء فقط (status = purchasing) — محاكاة renderBuyerShops. */
    fun buyerOrders(): List<Order> = orders.value.filter { it.status == "purchasing" }

    /** مجموع تكلفة شراء الشرائح المعلقة عبر كل الطلبات قيد الشراء — محاكاة buyerPendingCash. */
    fun buyerPendingCash(): Int {
        var sum = 0
        for (o in buyerOrders()) {
            for (s in com.tatbiqi.app.ui.screens.segmentFrom(o.segmentsJson)) {
                if (s.status == "pending") sum += segmentCost(s)
            }
        }
        return sum
    }

    fun buyerPendingSegCount(): Int {
        var n = 0
        for (o in buyerOrders()) {
            n += com.tatbiqi.app.ui.screens.segmentFrom(o.segmentsJson).count { it.status == "pending" }
        }
        return n
    }

    /** تكلفة الشريحة = سعر الشراء (من المحل) — ما يدفعه المشتري فعلاً. */
    fun segmentCost(seg: Segment): Int {
        if (seg.costAmount > 0) return seg.costAmount
        return seg.items.sumOf { it.buyPrice * it.quantity }
    }

    /** سعر بيع الشريحة للزبون (لعلم المشتري فقط). */
    fun segmentSell(seg: Segment): Int = seg.items.sumOf { it.price * it.quantity }

    /**
     * تأكيد الشريحة من قبل المشتري — محاكاة buyerConfirm في HTML.
     * status = "purchased" (مع المبلغ المدفوع) أو "unavailable".
     * يحدّث حالة الطلب حسب بقية الشرائح:
     *   - كلها unavailable → unavailable
     *   - بعضها purchased → purchasing (متبقٍ) أو purchased (انتهى)
     */
    fun confirmSegment(orderId: String, shopId: String, status: String, paidAmount: Int) {
        viewModelScope.launch {
            val order = repo.getOrder(orderId) ?: return@launch
            val segments = com.tatbiqi.app.ui.screens.segmentFrom(order.segmentsJson)
                .map { if (it.shopId == shopId) {
                    if (status == "purchased") it.copy(status = "purchased", cash = paidAmount, paid = true)
                    else it.copy(status = "unavailable", cash = 0, paid = false)
                } else it }

            val stillPending = segments.any { it.status == "pending" }
            val anyPurchased = segments.any { it.status == "purchased" }
            val newStatus = when {
                stillPending -> "purchasing"
                anyPurchased && segments.all { it.status == "purchased" } -> "purchased"
                segments.all { it.status == "unavailable" } -> "unavailable"
                else -> "purchasing"
            }

            repo.upsertOrder(order.copy(
                status = newStatus,
                segmentsJson = com.tatbiqi.app.data.model.encodeSegments(segments),
                updatedAt = System.currentTimeMillis()
            ))
            showToast(if (status == "purchased") "✅ تم تأكيد الشراء: $paidAmount ر.ي" else "تم تعليم غير متوفر")
        }
    }

    fun changeStatus(id: String, status: String) {
        viewModelScope.launch {
            val o = repo.getOrder(id) ?: return@launch
            // 🔧 تغيير الحالة مع ضبط دين الزبون (مطابق HTML: الإلغاء يخصم الدين، إعادة التفعيل يعيده)
            if (status == "cancelled" && o.status != "cancelled" && o.remainingAmount > 0) {
                adjustCustomerDebt(o.customerId, -o.remainingAmount)
            } else if (o.status == "cancelled" && status != "cancelled" && o.remainingAmount > 0) {
                adjustCustomerDebt(o.customerId, o.remainingAmount)
            }
            repo.upsertOrder(o.copy(status = status, updatedAt = System.currentTimeMillis()))
        }
    }

    fun deleteOrder(id: String) {
        viewModelScope.launch {
            val o = repo.getOrder(id) ?: return@launch
            if (o.remainingAmount > 0) adjustCustomerDebt(o.customerId, -o.remainingAmount)
            repo.upsertOrder(o.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
        }
    }

    // ---------- الدين المركزي (النظمي: كل ميزة تلمسه) ----------
    fun adjustCustomerDebt(customerId: String, delta: Int) {
        viewModelScope.launch {
            val c = repo.getCustomer(customerId) ?: return@launch
            repo.upsertCustomer(c.copy(totalDebt = (c.totalDebt + delta).coerceAtLeast(0), updatedAt = System.currentTimeMillis()))
        }
    }

    /** إعادة احتساب الدين لكل الزبائن من الطلبات النشطة — محاكاة خريطة renderDebts. */
    fun recomputeAllDebts() {
        viewModelScope.launch {
            val orders = repo.getAllOrders().filter { it.status != "cancelled" && !it.isDeleted }
            val map = mutableMapOf<String, Int>()
            orders.forEach { o -> if (o.remainingAmount > 0) map[o.customerId] = (map[o.customerId] ?: 0) + o.remainingAmount }
            map.forEach { (cid, total) ->
                val c = repo.getCustomer(cid) ?: return@forEach
                if (c.totalDebt != total) repo.upsertCustomer(c.copy(totalDebt = total, updatedAt = System.currentTimeMillis()))
            }
            // صفّر من بلا دين
            val withDebt = map.keys
            repo.getAllCustomers().filter { it.totalDebt > 0 && it.id !in withDebt }
                .forEach { repo.upsertCustomer(it.copy(totalDebt = 0, updatedAt = System.currentTimeMillis())) }
        }
    }

    // ---------- تسجيل دفعة بعد الطلب (recordPaymentUI) ----------
    fun recordPayment(orderId: String, amount: Int) {
        viewModelScope.launch {
            val o = repo.getOrder(orderId) ?: return@launch
            if (amount <= 0) { showToast("أدخل مبلغاً صحيحاً"); return@launch }
            if (amount > o.remainingAmount) { showToast("المبلغ أكبر من المتبقي"); return@launch }
            repo.upsertOrder(o.copy(
                paidAmount = o.paidAmount + amount,
                remainingAmount = o.remainingAmount - amount,
                updatedAt = System.currentTimeMillis()
            ))
            adjustCustomerDebt(o.customerId, -amount)
            showToast("تم تسجيل الدفعة: $amount ر.ي")
        }
    }

    // ---------- الديون (renderDebts) ----------
    fun debtors(): List<Pair<Customer, Pair<Int, Int>>> {
        val active = orders.value.filter { it.status != "cancelled" && it.remainingAmount > 0 }
        val map = mutableMapOf<String, Pair<Int, Int>>()
        active.forEach { o ->
            val cur = map[o.customerId] ?: (0 to 0)
            map[o.customerId] = (cur.first + o.remainingAmount) to (cur.second + 1)
        }
        return map.mapNotNull { (cid, v) ->
            val c = customers.value.find { it.id == cid } ?: return@mapNotNull null
            c to (c.totalDebt to v.second)
        }.sortedByDescending { it.second.first }
    }
    fun grandDebt(): Int = debtors().sumOf { it.second.first }

    // ---------- التسليم (delivery) ----------
    fun deliveringOrders(): List<Order> = orders.value.filter { it.status == "delivering" }

    fun confirmDelivery(orderId: String, receivedAmount: Int) {
        viewModelScope.launch {
            val o = repo.getOrder(orderId) ?: return@launch
            var paid = o.paidAmount; var remaining = o.remainingAmount
            if (receivedAmount > 0 && receivedAmount <= remaining) {
                paid += receivedAmount; remaining -= receivedAmount
                adjustCustomerDebt(o.customerId, -receivedAmount)
            }
            repo.upsertOrder(o.copy(status = "delivered", paidAmount = paid, remainingAmount = remaining, updatedAt = System.currentTimeMillis()))
            showToast("تم التسليم ✅" + if (receivedAmount > 0) " ومقبوض $receivedAmount" else "")
        }
    }

    // ---------- إدارة المستخدمين (renderUsers) ----------
    fun addUser(username: String, password: String, name: String, grantDelivery: Boolean) {
        viewModelScope.launch {
            if (repo.getUserByUsername(username.trim()) != null) { showToast("اسم المستخدم موجود"); return@launch }
            val perms = User.buyerPermissions().toMutableMap()
            if (grantDelivery) { perms["delivery.view"] = true; perms["delivery.confirm"] = true }
            repo.upsertUser(User(
                id = "u${System.currentTimeMillis()}", username = username.trim(),
                password = password, name = name.ifEmpty { username.trim() }, role = "buyer",
                isActive = true, workspaceId = "workspace-001", permissions = perms,
                updatedAt = System.currentTimeMillis()
            ))
            showToast("تمت إضافة المشتري ✅")
        }
    }
    fun toggleUserActive(id: String) {
        viewModelScope.launch {
            val u = repo.getUser(id) ?: return@launch
            repo.upsertUser(u.copy(isActive = !u.isActive, updatedAt = System.currentTimeMillis()))
        }
    }
    fun setUserPermission(id: String, key: String, value: Boolean) {
        viewModelScope.launch {
            val u = repo.getUser(id) ?: return@launch
            repo.upsertUser(u.copy(permissions = u.permissions + (key to value), updatedAt = System.currentTimeMillis()))
        }
    }
    fun deleteUser(id: String) {
        viewModelScope.launch {
            val u = repo.getUser(id) ?: return@launch
            if (u.role == "owner") { showToast("لا تحذف المالك"); return@launch }
            repo.deleteUser(id)
            showToast("تم حذف المستخدم")
        }
    }

    // ---------- كشف وتنظيف التكرارات (checkAllDuplicates) ----------
    data class DupGroup(val name: String, val count: Int, val ids: List<String>)
    fun checkAllDuplicates(): List<DupGroup> {
        val groups = mutableListOf<DupGroup>()
        fun collect(items: List<Pair<String, String>>) { // (key, id)
            items.groupBy { it.first.lowercase().trim() }.forEach { (key, list) ->
                if (list.size > 1) groups.add(DupGroup(key, list.size, list.map { it.second }))
            }
        }
        collect(users.value.map { it.username to it.id })
        collect(customers.value.map { it.name to it.id })
        collect(shops.value.map { it.name to it.id })
        collect(products.value.groupBy { it.shopId + "|" + it.name.lowercase().trim() }
            .values.filter { it.size > 1 }.flatten().map { it.name to it.id })
        return groups
    }

    fun cleanupDuplicates() {
        viewModelScope.launch {
            var removed = 0
            // المستخدمون: احتفظ بأحدث، لا تحذف المالك
            users.value.groupBy { it.username.lowercase().trim() }.forEach { (_, list) ->
                if (list.size > 1) {
                    val keep = list.filter { it.role != "owner" }.maxByOrNull { it.updatedAt } ?: list.first()
                    list.filter { it.id != keep.id && it.role != "owner" }.forEach { repo.deleteUser(it.id); removed++ }
                }
            }
            // الزبائن والمحلات: احتفظ بالأحدث
            customers.value.groupBy { it.name.lowercase().trim() }.forEach { (_, list) ->
                if (list.size > 1) {
                    val keep = list.maxByOrNull { it.updatedAt }!!
                    list.filter { it.id != keep.id }.forEach { repo.deleteCustomer(it.id); removed++ }
                }
            }
            shops.value.groupBy { it.name.lowercase().trim() }.forEach { (_, list) ->
                if (list.size > 1) {
                    val keep = list.maxByOrNull { it.updatedAt }!!
                    list.filter { it.id != keep.id }.forEach { repo.deleteShop(it.id); removed++ }
                }
            }
            showToast(if (removed > 0) "تم تنظيف $removed مكرر 🧹" else "لا توجد مكررات 🎉")
        }
    }



    // ---------- مشاركة من واتساب (استقبال) ----------
    val sharedImage: StateFlow<String?> = repo.sharedImage
    fun consumeSharedImage() = repo.consumeSharedImage()

    // ---------- Reports ----------
    fun monthlySales(): Int = orders.value.filter { it.status == "delivered" }.sumOf { it.totalAmount }
    fun totalProfit(): Int = orders.value.filter { it.status == "delivered" }.sumOf { it.totalAmount - it.costAmount }
    fun debtsTotal(): Int = orders.value.sumOf { it.remainingAmount.coerceAtLeast(0) }
}
