package com.tatbiqi.app.ui.motion

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput

/**
 * مكونات الحركة — انتقالات دخول/خروج، نقر مرن، عناصر متتالية، وميض تحميل.
 * كلها مبنية على نظام AppMotion وتقلّد أنيميشن HTML.
 */

/** انتقالات الدخول/الخروج للصفحات — محاكاة page-enter (slideUp + fadeIn). */
object MotionTransitions {
    val enter: EnterTransition = slideInVertically(
        animationSpec = tween(AppMotion.NORMAL),
        initialOffsetY = { it / 8 }
    ) + fadeIn(tween(AppMotion.NORMAL)) + scaleIn(
        animationSpec = tween(AppMotion.NORMAL), initialScale = 0.97f,
        transformOrigin = TransformOrigin(0.5f, 0.5f)
    )
    val exit: ExitTransition = slideOutVertically(
        animationSpec = tween(AppMotion.FAST), targetOffsetY = { it / 12 }
    ) + fadeOut(tween(AppMotion.FAST)) + scaleOut(
        animationSpec = tween(AppMotion.FAST), targetScale = 0.97f
    )
}

/** spring soft spec للمكونات. */
fun <T> springSoft() = androidx.compose.animation.core.spring<T>(
    dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy,
    stiffness = androidx.compose.animation.core.Spring.StiffnessLow
)

/** حاوية صفحة متحركة — تُغلَّف بها كل شاشة للانتقال عند تغيّر المفتاح. */
@Composable
fun AnimatedPage(
    key: Any,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    AnimatedVisibility(
        visible = true,
        enter = MotionTransitions.enter,
        exit = MotionTransitions.exit,
        modifier = modifier,
        content = { Box(Modifier.fillMaxSize(), content = content) }
    )
}

/** معدّل بضغطة مرنة (scale على النقر) — محاكاة btn:active scale(.97). */
@Composable
fun Modifier.motionPress(onClick: () -> Unit): Modifier {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, springSoft())
    return this
        .graphicsLayer {
            scaleX = scale; scaleY = scale; transformOrigin = TransformOrigin(0.5f, 0.5f)
        }
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                onTap = { onClick() }
            )
        }
}

/** عنصر متتالي — يحاكي .stagger > * (تأخير تدريجي). */
@Composable
fun StaggerItem(
    index: Int,
    visible: Boolean = true,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(AppMotion.NORMAL, delayMillis = index * 60)) +
            slideInVertically(tween(AppMotion.NORMAL, delayMillis = index * 60)) { it / 4 },
        exit = fadeOut(tween(AppMotion.FAST)) + slideOutVertically(tween(AppMotion.FAST)) { it / 4 },
        modifier = modifier
    ) { content() }
}

/** هيكل تحميل متوهّج (Skeleton/Shimmer) — محاكاة shimmer. */
@Composable
fun ShimmerBox(
    modifier: Modifier = Modifier,
    baseColor: Color = Color(0xFFE2E8F0),
    highlightColor: Color = Color(0xFFF1F5F9)
) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val x by transition.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1300), RepeatMode.Restart),
        label = "shimmerX"
    )
    Box(
        modifier = modifier.background(
            Brush.linearGradient(
                colors = listOf(baseColor, highlightColor, baseColor),
                start = Offset(x * 1000, 0f),
                end = Offset(x * 1400, 0f)
            )
        )
    )
}

/** أيقونة تطفو بلطف — محاكاة float. */
@Composable
fun FloatingIcon(emoji: String, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "float")
    val y by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "fy")
    androidx.compose.material3.Text(
        emoji,
        style = androidx.compose.material3.MaterialTheme.typography.headlineMedium,
        modifier = modifier.graphicsLayer { translationY = y * -6f }
    )
}
