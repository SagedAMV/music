package com.tatbiqi.app.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.data.model.User
import com.tatbiqi.app.ui.motion.motionPress
import com.tatbiqi.app.ui.navigation.Views
import com.tatbiqi.app.ui.components.StatCard
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel
import com.tatbiqi.app.ui.theme.AppColors

/**
 * لوحة التحكم — محتوى تبويب dashboard في HTML.
 * يعرض إحصائيات + أزرار سريعة، مطابق لـ renderDashboard.
 */
@Composable
fun DashboardScreen(
    vm: MainViewModel,
    auth: AuthViewModel,
    currentUser: User?,
    navigateTo: (String, Map<String, String>) -> Unit
) {
    val orders by vm.orders.collectAsState()
    val userName = currentUser?.name ?: "مستخدم"
    val roleLabel = if (currentUser?.role == "buyer") "مهام الشراء" else "لوحة التحكم"

    val stats = listOf(
        Stat("طلبات جديدة", orders.count { it.status == "new" }, "🆕", AppColors.GradBlue),
        Stat("قيد الشراء", orders.count { it.status == "purchasing" }, "🛒", AppColors.GradOrange),
        Stat("قيد التسليم", orders.count { it.status == "delivering" }, "🚚", AppColors.GradPurple),
        Stat("تم التسليم", orders.count { it.status == "delivered" }, "✅", AppColors.GradGreen)
    )

    LazyColumn(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("مرحباً، $userName 👋", style = MaterialTheme.typography.headlineSmall)
            Text("$roleLabel • ${currentUser?.username ?: ""}", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        // شبكة الإحصائيات (مثل grid-stats في HTML)
        stats.chunked(2).forEach { rowStats ->
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowStats.forEach { s ->
                        Box(Modifier.weight(1f)) {
                            StatCard(s.label, s.value.toString(), s.gradient, s.icon)
                        }
                    }
                }
            }
        }
        // أزرار سريعة (مثل quick-row في HTML)
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickButton(Modifier.weight(1f), "➕", "طلب جديد", "شرائح حسب المحل") { navigateTo(Views.ORDER_FORM, emptyMap()) }
                QuickButton(Modifier.weight(1f), "📋", "الطلبات", "${orders.size} طلب") { navigateTo(Views.ORDERS, emptyMap()) }
                QuickButton(Modifier.weight(1f), "📦", "التسليم", "قيد التسليم") { navigateTo(Views.DELIVERY, emptyMap()) }
            }
        }
        // ملخص مالي
        item {
            androidx.compose.foundation.layout.Box(
                Modifier
                    .fillMaxWidth()
                    .background(AppColors.GradDark)
                    .padding(18.dp)
            ) {
                Column {
                    Text("إجمالي المبيعات (تم التسليم)", style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.8f))
                    Text("${vm.monthlySales()} ر.ي", style = MaterialTheme.typography.headlineMedium,
                        color = Color.White)
                }
            }
        }
        item {
            Text("أحدث الطلبات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        orders.take(5).forEach { o ->
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().motionPress { navigateTo(Views.ORDER_DETAIL, mapOf("orderId" to o.id)) }) {
                    Row(Modifier.fillMaxWidth().padding(14.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(o.customerName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("${o.totalAmount} ر.ي", style = MaterialTheme.typography.bodyMedium, color = AppColors.Blue)
                        }
                        com.tatbiqi.app.ui.components.StatusBadge(o.status)
                    }
                }
            }
        }
    }
}

private data class Stat(val label: String, val value: Int, val icon: String, val gradient: Brush)

@Composable
private fun QuickButton(modifier: Modifier, icon: String, label: String, sub: String, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier.motionPress { onClick() }
    ) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, style = MaterialTheme.typography.headlineMedium)
            Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            Text(sub, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
