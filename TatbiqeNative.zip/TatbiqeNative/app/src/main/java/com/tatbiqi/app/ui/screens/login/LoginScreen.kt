package com.tatbiqi.app.ui.screens.login

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.ui.components.LabeledField
import com.tatbiqi.app.ui.components.PrimaryButton
import com.tatbiqi.app.ui.components.LoadingState
import com.tatbiqi.app.ui.screens.AuthViewModel

/**
 * شاشة الدخول — محاكاة doLogin في HTML.
 * تعمل أوفلاين (مصادقة محلية) ثم تزامن سحابي.
 */
@Composable
fun LoginScreen(vm: AuthViewModel, onLoggedIn: () -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var useCloud by remember { mutableStateOf(true) }
    val state by vm.state.collectAsState()

    com.tatbiqi.app.ui.motion.AnimatedPage(key = "login") {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        com.tatbiqi.app.ui.motion.FloatingIcon("📱")
        Text("تطبيقي", style = MaterialTheme.typography.headlineLarge)
        Text("نظام إدارة البسطة والمحلات", style = MaterialTheme.typography.bodyMedium)

        Spacer(Modifier.height(24.dp))
        LabeledField(username, { username = it }, "اسم المستخدم")
        Spacer(Modifier.height(12.dp))
        androidx.compose.material3.OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("كلمة المرور") },
            singleLine = true,
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                keyboardType = androidx.compose.ui.text.input.KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = useCloud, onCheckedChange = { useCloud = it })
            Text("مزامنة سحابية (Firebase)")
        }

        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(16.dp))
        if (state.loading) {
            LoadingState()
        } else {
            androidx.compose.material3.Button(
                onClick = { vm.login(username, password, useCloud) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("دخول") }
        }
        Text(
            "للدخول الافتراضي: admin / admin123",
            style = MaterialTheme.typography.bodySmall
        )
    }
    }

    LaunchedEffect(state.isLoggedIn) {
        if (state.isLoggedIn) onLoggedIn()
    }
}
