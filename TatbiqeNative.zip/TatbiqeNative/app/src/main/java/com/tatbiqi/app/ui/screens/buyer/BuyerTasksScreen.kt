package com.tatbiqi.app.ui.screens.buyer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.data.model.Order
import com.tatbiqi.app.data.model.Shop
import com.tatbiqi.app.ui.components.EmptyState
import com.tatbiqi.app.ui.motion.motionPress
import com.tatbiqi.app.ui.navigation.Views
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel
import com.tatbiqi.app.ui.screens.segmentFrom

/**
 * شاشة "المحلات الذكية" للمشتري — محاكاة renderBuyerShops في HTML.
 * تعرض فقط الطلبات قيد الشراء (purchasing) وتجمع الشرائح المعلقة لكل محل،
 * مرتبة حسب الأكثر طلبات، مع لافتة النقد المطلوب أخذها.
 */
@Composable
fun BuyerTasksScreen(
    vm: MainViewModel,
    auth: AuthViewModel,
    navigateTo: (String, Map<String, String>) -> Unit
) {
    val shops by vm.shops.collectAsState()
    val orders by vm.orders.collectAsState()
    val cash = vm.buyerPendingCash()
    val segs = vm.buyerPendingSegCount()

        LazyColumn(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { CashBanner(cash = cash, pending = segs) }
            item {
                Text("المحلات الذكية", style = MaterialTheme.typography.headlineSmall)
                Text("رُتبت حسب الأكثر طلبات — يسهّل حركة المشتري", style = MaterialTheme.typography.bodySmall)
            }

            val stats = shopStats(shops, orders, vm)
            if (stats.isEmpty()) {
                item { EmptyState("لا توجد مهام شراء الآن 🎉", "🛍️") }
            } else {
                items(stats.size) { i ->
                    val s = stats[i]
                    com.tatbiqi.app.ui.motion.StaggerItem(index = i) {
                        ShopTaskCard(s, onClick = { navigateTo(Views.BUYER_SHOP_ORDERS, mapOf("shopId" to s.shop.id)) })
                    }
                }
            }
        }
}

/** بيانات ملخّصة لمحل واحد — محاكاة خريطة stats في renderBuyerShops. */
data class ShopStat(val shop: Shop, val count: Int, val customers: Int, val expected: Int)

fun shopStats(shops: List<Shop>, orders: List<Order>, vm: MainViewModel): List<ShopStat> {
    val active = orders.filter { it.status == "purchasing" }
    val result = shops.mapNotNull { shop ->
        val segs = active.flatMap { o ->
            com.tatbiqi.app.ui.screens.segmentFrom(o.segmentsJson)
                .filter { it.shopId == shop.id && it.status == "pending" }
                .map { seg -> Triple(o, seg, vm) }
        }
        if (segs.isEmpty()) null
        else ShopStat(
            shop = shop,
            count = segs.size,
            customers = segs.map { it.first.customerId }.toSet().size,
            expected = segs.sumOf { vm.segmentCost(it.second) }
        )
    }
    return result.sortedByDescending { it.count }
}

@Composable
fun CashBanner(cash: Int, pending: Int) {
    val done = cash <= 0 && pending == 0
    Card(
        colors = CardDefaults.cardColors(containerColor = if (done) Color(0xFF10B981) else Color(0xFF2563EB))
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                if (done) "لا تحتاج مبلغاً الآن 🎉" else "خذ معك هذا المبلغ قبل الذهاب للمحلات",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White
            )
            Text("$cash ر.ي", style = MaterialTheme.typography.headlineLarge, color = Color.White)
            Text(
                if (done) "كل المهام اشتريت — القيمة 0"
                else "مجموع أسعار الشراء لـ $pending شريحة معلقة",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.85f)
            )
        }
    }
}

@Composable
fun ShopTaskCard(stat: ShopStat, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().motionPress { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth()) {
                Text("🏪 ${stat.shop.name}", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.weight(1f))
                Text("${stat.count} طلب", style = MaterialTheme.typography.labelLarge,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        .background(color = Color(0xFF2563EB), shape = androidx.compose.foundation.shape.RoundedCornerShape(50)))
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                Text("👥 ${stat.customers} زبون", style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        .background(color = MaterialTheme.colorScheme.surfaceVariant, shape = androidx.compose.foundation.shape.RoundedCornerShape(50)))
                Spacer(Modifier.weight(1f))
                Text("💰 ${stat.expected} ر.ي", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
