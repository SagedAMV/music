package com.tatbiqi.app.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tatbiqi.app.data.model.User
import com.tatbiqi.app.data.repository.AppRepository
import com.tatbiqi.app.data.session.SessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class AuthState(
    val loading: Boolean = false,
    val error: String? = null,
    val currentUser: User? = null,
    val isLoggedIn: Boolean = false
)

class AuthViewModel(
    private val repo: AppRepository,
    private val session: SessionManager
) : ViewModel() {

    private val _state = MutableStateFlow(AuthState())
    val state: StateFlow<AuthState> = _state

    init { restoreSession() }

    /** محاكاة doLogin + remember session. */
    fun login(username: String, password: String, useCloud: Boolean) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            repo.seedIfEmpty()   // 🔧 ضمان وجود الحسابات الافتراضية قبل الدخول
            val user = repo.getUserByUsername(username.trim())
            when {
                user == null -> _state.value = _state.value.copy(
                    loading = false, error = "اسم المستخدم غير موجود")
                !user.isActive -> _state.value = _state.value.copy(
                    loading = false, error = "الحساب معطّل")
                user.password != password && !user.cloud -> _state.value = _state.value.copy(
                    loading = false, error = "كلمة المرور غير صحيحة")
                else -> {
                    session.saveSession(user, useCloud)
                    _state.value = AuthState(currentUser = user, isLoggedIn = true)
                }
            }
        }
    }

    fun logout() {
        viewModelScope.launch { session.clearSession() }
        _state.value = AuthState()
    }

    private fun restoreSession() {
        viewModelScope.launch {
            val loggedIn = session.isLoggedIn()
            if (!loggedIn) { _state.value = AuthState(); return@launch }
            val id = session.currentUserId.first()
            val user = id?.let { repo.getUser(it) }
            _state.value = AuthState(
                currentUser = user, isLoggedIn = user != null)
            if (user == null) session.clearSession()
        }
    }

    fun currentUser(): User? = _state.value.currentUser
    fun has(perm: String): Boolean = _state.value.currentUser?.has(perm) ?: false
}
