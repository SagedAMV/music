package com.tatbiqi.app.ui.screens.shop

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.ui.components.AppScaffold
import com.tatbiqi.app.ui.components.EmptyState
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel

/**
 * تفاصيل محل — محاكاة renderShopDetail: معلومات المحل + منتجاته.
 */
@Composable
fun ShopDetailScreen(vm: MainViewModel, auth: AuthViewModel, shopId: String, onBack: () -> Unit) {
    val shops by vm.shops.collectAsState()
    val products by vm.products.collectAsState()
    val shop = shops.find { it.id == shopId }
    val shopProducts = products.filter { it.shopId == shopId }

    AppScaffold(
        title = shop?.name ?: "المحل",
        navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }
    ) {
        if (shop == null) { EmptyState("المحل غير موجود", "🏪") }
        else Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp)) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text("🏪 ${shop.name}", style = MaterialTheme.typography.titleLarge)
                    Text(shop.phone, style = MaterialTheme.typography.bodyMedium)
                    Text(shop.note, style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("منتجات المحل (${shopProducts.size})", style = MaterialTheme.typography.titleMedium)
            if (shopProducts.isEmpty()) {
                EmptyState("لا توجد منتجات لهذا المحل", "🏷️")
            } else {
                shopProducts.forEach { p ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.padding(vertical = 4.dp)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, style = MaterialTheme.typography.titleMedium)
                                Text("بيع: ${p.price} • شراء: ${p.buyPrice} • كمية: ${p.stock}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}
