package com.tatbiqi.app.data.remote

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream

/**
 * ضغط الصور — محاكاة compressImageDataUrl في HTML.
 * يقلّص الأبعاد إلى maxDim مع الحفاظ على النسبة، ويضغط بجودة JPEG.
 * إذا كانت الصورة أصغر من الحد، تُترك كما هي (أقصى جودة).
 */
object ImageCompressor {

    const val MAX_DIM = 1000
    const val QUALITY = 80
    private const val COMPRESS_THRESHOLD = 400 * 1024 // 400KB

    /** يضغط بايتات الصورة ويعيد بايتات أصغر (JPEG). */
    fun compress(data: ByteArray): ByteArray {
        if (data.size < COMPRESS_THRESHOLD) return data
        val bmp = BitmapFactory.decodeByteArray(data, 0, data.size) ?: return data
        val scale = Math.min(1.0, MAX_DIM.toDouble() / Math.max(bmp.width, bmp.height))
        if (scale >= 1.0) return data
        val w = Math.max(1, (bmp.width * scale).toInt())
        val h = Math.max(1, (bmp.height * scale).toInt())
        val scaled = Bitmap.createScaledBitmap(bmp, w, h, true)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, QUALITY, out)
        if (!bmp.isRecycled) bmp.recycle()
        if (!scaled.isRecycled) scaled.recycle()
        return out.toByteArray()
    }
}
