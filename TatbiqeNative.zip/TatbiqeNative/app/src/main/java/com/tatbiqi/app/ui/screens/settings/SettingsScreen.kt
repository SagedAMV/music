package com.tatbiqi.app.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.data.remote.SyncManager
import com.tatbiqi.app.ui.components.PrimaryButton
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel
import kotlinx.coroutines.launch

/**
 * الإعدادات — محتوى تبويب settings: الحساب + المزامنة + تسجيل الخروج.
 */
@Composable
fun SettingsScreen(
    vm: MainViewModel,
    auth: AuthViewModel,
    syncManager: SyncManager,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var dark by remember { androidx.compose.runtime.mutableStateOf(false) }
    val user = auth.currentUser()

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(14.dp)) {
                Text("الحساب", style = MaterialTheme.typography.titleMedium)
                Text("المستخدم: ${user?.name ?: ""}", style = MaterialTheme.typography.bodyMedium)
                Text("الدور: ${user?.role ?: ""}", style = MaterialTheme.typography.bodyMedium)
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("الوضع الداكن", modifier = Modifier.weight(1f))
                    Switch(checked = dark, onCheckedChange = { dark = it })
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(14.dp)) {
                Text("المزامنة السحابية", style = MaterialTheme.typography.titleMedium)
                Text("يعمل التطبيق أوفلاين ويتزامن تلقائياً عند التوفر", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                PrimaryButton("مزامنة الآن", onClick = {
                    scope.launch {
                        syncManager.pushAll()
                        syncManager.pullAll()
                    }
                })
            }
        }
        Spacer(Modifier.height(12.dp))
        PrimaryButton("تسجيل الخروج", onClick = { onBack() })
    }
}
