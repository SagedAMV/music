package com.tatbiqi.app.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

/**
 * نظام التصميم — مطابق لـ CSS متغيرات HTML:
 * --blue:#2563EB  --green:#10B981  --red:#EF4444  --bg:#F8FAFC
 * --card:#FFF  --border:#E2E8F0  --shadow  --radius:16px
 */
object AppColors {
    val Blue = Color(0xFF2563EB)
    val BlueDark = Color(0xFF1D4ED8)
    val Green = Color(0xFF10B981)
    val GreenDark = Color(0xFF059669)
    val Red = Color(0xFFEF4444)
    val Amber = Color(0xFFF59E0B)
    val Purple = Color(0xFF7C3AED)
    val Orange = Color(0xFFF97316)
    val Teal = Color(0xFF14B8A6)

    val Bg = Color(0xFFF8FAFC)
    val BgSoft = Color(0xFFF1F5F9)
    val Card = Color(0xFFFFFFFF)
    val Border = Color(0xFFE2E8F0)
    val Text = Color(0xFF0F172A)
    val Muted = Color(0xFF64748B)

    // التدرجات (مطابقة HTML)
    val GradBlue = Brush.linearGradient(listOf(Color(0xFF3B82F6), Color(0xFF2563EB)))
    val GradOrange = Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFFD97706)))
    val GradPurple = Brush.linearGradient(listOf(Color(0xFF8B5CF6), Color(0xFF7C3AED)))
    val GradGreen = Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF059669)))
    val GradRed = Brush.linearGradient(listOf(Color(0xFFEF4444), Color(0xFFDC2626)))
    val GradDark = Brush.linearGradient(listOf(Color(0xFF0F172A), Color(0xFF1E293B)))
}

object AppShapes {
    val Small = RoundedCornerShape(10.dp)
    val Medium = RoundedCornerShape(12.dp)
    val Card = RoundedCornerShape(16.dp)      // --radius:16px
    val CardLg = RoundedCornerShape(20.dp)    // --radius-lg:20px
    val Pill = RoundedCornerShape(50)
}
