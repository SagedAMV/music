package com.tatbiqi.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.tatbiqi.app.ui.theme.AppShapes as DSShapes

// مطابقة ألوان HTML (#2563EB أساسي + خلفيات)
private val LightColors = lightColorScheme(
    primary = AppColors.Blue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF1E3A8A),
    secondary = AppColors.Green,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD1FAE5),
    onSecondaryContainer = Color(0xFF064E3B),
    tertiary = AppColors.Purple,
    background = AppColors.Bg,
    onBackground = AppColors.Text,
    surface = AppColors.Card,
    onSurface = AppColors.Text,
    surfaceVariant = AppColors.BgSoft,
    onSurfaceVariant = AppColors.Muted,
    outline = AppColors.Border,
    error = AppColors.Red,
    onError = Color.White
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF60A5FA),
    onPrimary = Color(0xFF0F172A),
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = Color(0xFFDBEAFE),
    secondary = Color(0xFF34D399),
    background = Color(0xFF0B1220),
    surface = Color(0xFF131E35),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF111C33),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF1E334D),
    error = Color(0xFFF87171)
)

private val ThemeShapes = Shapes(
    small = com.tatbiqi.app.ui.theme.AppShapes.Small,
    medium = com.tatbiqi.app.ui.theme.AppShapes.Medium,
    large = com.tatbiqi.app.ui.theme.AppShapes.Card
)

@Composable
fun TatbiqeTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        shapes = ThemeShapes,
        content = content
    )
}
