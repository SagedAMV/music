package com.tatbiqi.app.ui.screens.order

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.data.model.Customer
import com.tatbiqi.app.data.model.OrderItem
import com.tatbiqi.app.data.model.Segment
import com.tatbiqi.app.ui.components.AppScaffold
import com.tatbiqi.app.ui.components.LabeledField
import com.tatbiqi.app.ui.components.PrimaryButton
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel
import kotlinx.coroutines.launch

/**
 * نموذج إنشاء/تعديل الطلب — محاكاة renderOrderForm مع segments[] و items[].
 */
@Composable
fun OrderFormScreen(
    vm: MainViewModel,
    auth: AuthViewModel,
    orderId: String?,
    onBack: () -> Unit
) {
    val snackbar = remember { SnackbarHostState() }
    val shops by vm.shops.collectAsState()
    val customers by vm.customers.collectAsState()
    val scope = rememberCoroutineScope()

    var selectedCustomerId by remember { mutableStateOf<String?>(null) }
    var segments by remember { mutableStateOf<List<Segment>>(emptyList()) }
    var paidAmount by remember { mutableStateOf("0") }

    // 🔧 صورة مشتركة من واتساب → تُضاف كشريحة مع صورة (الزبون والمحل يُختاران)
    LaunchedEffect(Unit) {
        if (vm.sharedImage.value != null) {
            val img = vm.sharedImage.value!!
            segments = listOf(Segment(
                shopId = "__shared__", shopName = "⚠️ اختر المحل",
                items = listOf(OrderItem(name = "صورة مشتركة", quantity = 1, imageUrl = img))
            ))
            vm.consumeSharedImage()
        }
    }

    AppScaffold(
        title = if (orderId == null) "طلب جديد" else "تعديل الطلب",
        navigationIcon = {
            TextButton(onClick = onBack) { Text("رجوع") }
        },
        snackbarHostState = snackbar
    ) {
        LazyColumn(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                // اختيار الزبون
                CustomerDropdown(customers, selectedCustomerId) { selectedCustomerId = it }
            }
            item {
                // إضافة شريحة (محل)
                if (auth.has("orders.create")) {
                    ShopSegmentAdder(shops, segments) { seg ->
                        segments = segments + seg
                    }
                }
            }
            items(segments.size) { i ->
                SegmentCard(
                    segment = segments[i],
                    onUpdate = { updated -> segments = segments.mapIndexed { idx, s -> if (idx == i) updated else s } },
                    onRemove = { segments = segments.filterIndexed { idx, _ -> idx != i } }
                )
            }
            item {
                val (total, cost, profit) = vm.computeTotals(segments)
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("الإجمالي للزبون: $total ر.ي", style = MaterialTheme.typography.titleLarge)
                        Text("التكلفة: $cost ر.ي", style = MaterialTheme.typography.bodyMedium)
                        Text("الربح المتوقع: $profit ر.ي",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (profit >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                        Spacer(Modifier.height(8.dp))
                        LabeledField(paidAmount, { paidAmount = it }, "المبلغ المدفوع", isNumber = true)
                        Spacer(Modifier.height(12.dp))
                        PrimaryButton("حفظ الطلب") {
                            val customer = customers.find { it.id == selectedCustomerId }
                            vm.saveOrder(
                                id = orderId, customer = customer, segments = segments,
                                paidAmount = paidAmount.toIntOrNull() ?: 0
                            )
                            scope.launch { snackbar.showSnackbar("تم حفظ الطلب ✅") }
                            onBack()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SegmentCard(segment: Segment, onUpdate: (Segment) -> Unit, onRemove: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth()) {
                Text(segment.shopName.ifEmpty { "شريحة" }, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onRemove) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            }
            // إضافة صنف
            var name by remember { mutableStateOf("") }
            var price by remember { mutableStateOf("") }
            var qty by remember { mutableStateOf("1") }
            var buyPrice by remember { mutableStateOf("0") }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم") },
                    modifier = Modifier.weight(1f), singleLine = true)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(qty, { qty = it }, label = { Text("كمية") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(price, { price = it }, label = { Text("سعر البيع") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(buyPrice, { buyPrice = it }, label = { Text("سعر الشراء") }, modifier = Modifier.weight(1f), singleLine = true)
            }
            TextButton(onClick = {
                val item = OrderItem(
                    name = name, quantity = qty.toIntOrNull() ?: 1,
                    price = price.toIntOrNull() ?: 0, buyPrice = buyPrice.toIntOrNull() ?: 0
                )
                onUpdate(segment.copy(items = segment.items + item))
                name = ""; price = ""; qty = "1"; buyPrice = "0"
            }) { Text("+ إضافة صنف") }
            // قائمة الأصناف
            segment.items.forEachIndexed { idx, it ->
                Text("• ${it.name.ifEmpty { "صنف" }} × ${it.quantity} — ${it.price}",
                    style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopSegmentAdder(shops: List<com.tatbiqi.app.data.model.Shop>, segments: List<Segment>, onAdd: (Segment) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    var selectedShopId by remember { mutableStateOf<String?>(null) }
    val shop = shops.find { it.id == selectedShopId }

    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = shop?.name ?: "اختر محل",
            onValueChange = {},
            readOnly = true,
            label = { Text("محل") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded, onDismissRequest = { expanded = false }) {
            shops.forEach { s ->
                DropdownMenuItem(text = { Text(s.name) }, onClick = {
                    selectedShopId = s.id; expanded = false
                })
            }
            DropdownMenuItem(text = { Text("+ محل جديد") }, onClick = { expanded = false })
        }
    }
    if (selectedShopId != null) {
        PrimaryButton("إضافة شريحة للمحل") {
            onAdd(Segment(shopId = selectedShopId!!, shopName = shop?.name ?: ""))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDropdown(customers: List<Customer>, selectedId: String?, onSelect: (String?) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val selected = customers.find { it.id == selectedId }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = selected?.name ?: "زبون نقدي (بدون اختيار)",
            onValueChange = {},
            readOnly = true,
            label = { Text("الزبون") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("زبون نقدي") }, onClick = { onSelect(null); expanded = false })
            customers.forEach { c ->
                DropdownMenuItem(text = { Text(c.name) }, onClick = { onSelect(c.id); expanded = false })
            }
        }
    }
}
