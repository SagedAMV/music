package com.tatbiqi.app.ui.screens.customer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.data.model.Order
import com.tatbiqi.app.ui.components.AppScaffold
import com.tatbiqi.app.ui.components.EmptyState
import com.tatbiqi.app.ui.components.PrimaryButton
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel

/**
 * تفاصيل زبون — محاكاة renderCustomerDetail: معلوماته + دينه + طلباته + تسجيل دفعة.
 */
@Composable
fun CustomerDetailScreen(vm: MainViewModel, auth: AuthViewModel, customerId: String, onBack: () -> Unit) {
    val customers by vm.customers.collectAsState()
    val orders by vm.orders.collectAsState()
    val customer = customers.find { it.id == customerId }
    val custOrders = orders.filter { it.customerId == customerId && it.status != "cancelled" }
    val canPay = auth.has("orders.edit") || auth.has("customers.manage")
    var payAmount by remember { mutableStateOf("") }

    AppScaffold(
        title = customer?.name ?: "الزبون",
        navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }
    ) {
        if (customer == null) { EmptyState("الزبون غير موجود", "👤") }
        else Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp)) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text("👤 ${customer.name}", style = MaterialTheme.typography.titleLarge)
                    Text(customer.phone, style = MaterialTheme.typography.bodyMedium)
                    Text(customer.note, style = MaterialTheme.typography.bodySmall)
                    Text("الدين: ${customer.totalDebt} ر.ي", color = Color(0xFFDC2626), style = MaterialTheme.typography.titleMedium)
                }
            }
            Spacer(Modifier.height(12.dp))
            if (canPay && customer.totalDebt > 0) {
                Card {
                    Column(Modifier.padding(12.dp)) {
                        Text("تسجيل دفعة", style = MaterialTheme.typography.titleSmall)
                        OutlinedTextField(payAmount, { payAmount = it },
                            label = { Text("المبلغ (ر.ي)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Spacer(Modifier.height(8.dp))
                        // الدفع يُسجّل على أول طلب غير مسدّد بالكامل
                        PrimaryButton("تسجيل الدفعة") {
                            val amt = payAmount.toIntOrNull() ?: 0
                            val target = custOrders.filter { it.remainingAmount > 0 }.firstOrNull()
                            if (target != null && amt > 0) {
                                vm.recordPayment(target.id, amt)
                                payAmount = ""
                            } else { vm.showToast("لا يوجد دين مستحق أو مبلغ غير صحيح") }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
            Text("طلبات الزبون (${custOrders.size})", style = MaterialTheme.typography.titleMedium)
            if (custOrders.isEmpty()) { EmptyState("لا توجد طلبات", "📋") }
            else custOrders.forEach { o -> CustomerOrderRow(o) }
        }
    }
}

@Composable
fun CustomerOrderRow(o: Order) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp)) {
            Column(Modifier.weight(1f)) {
                Text("${o.totalAmount} ر.ي", style = MaterialTheme.typography.titleMedium)
                Text("الحالة: ${o.status} • المدفوع: ${o.paidAmount} • المتبقي: ${o.remainingAmount}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
