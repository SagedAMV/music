package com.tatbiqi.app.ui.screens.order

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.data.model.Order
import com.tatbiqi.app.ui.components.EmptyState
import com.tatbiqi.app.ui.motion.motionPress
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * قائمة الطلبات — محاكاة renderOrders في HTML + بحث/فلترة.
 */
@Composable
fun OrdersScreen(
    vm: MainViewModel,
    auth: AuthViewModel,
    currentUser: com.tatbiqi.app.data.model.User?,
    navigateTo: (String, Map<String, String>) -> Unit
) {
    val orders by vm.orders.collectAsState()
    var query by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf<String?>(null) }
    val isBuyer = currentUser?.role == "buyer"
    val filtered = orders.filter { o ->
        val okPerm = if (isBuyer) (o.status != "new") else true
        okPerm &&
        (query.isBlank() || o.customerName.contains(query, true) || o.customerPhone.contains(query, true)) &&
        (statusFilter == null || o.status == statusFilter)
    }

        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            if (isBuyer) {
                Text("🔒 وضع المشتري: ترى فقط طلباتك المخصصة — لا يمكنك إنشاء أو تعديل طلبات المالك.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(bottom = 8.dp))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("📋 الطلبات", style = MaterialTheme.typography.headlineSmall)
                if (auth.has("orders.create")) {
                    androidx.compose.material3.TextButton(onClick = { navigateTo(com.tatbiqi.app.ui.navigation.Views.ORDER_FORM, emptyMap()) }) {
                        Text("+ جديد")
                    }
                }
            }
            OutlinedTextField(query, { query = it }, label = { Text("🔍 بحث بالاسم أو الهاتف") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("new" to "جديد", "delivering" to "تسليم", "delivered" to "تم", "cancelled" to "ملغي")
                    .forEach { (s, label) ->
                        androidx.compose.material3.FilterChip(
                            selected = statusFilter == s,
                            onClick = { statusFilter = if (statusFilter == s) null else s },
                            label = { Text(label) }
                        )
                    }
            }
            if (filtered.isEmpty()) {
                EmptyState("لا توجد نتائج", "📋")
            } else {
                androidx.compose.foundation.lazy.LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filtered.size) { i ->
                        com.tatbiqi.app.ui.motion.StaggerItem(index = i) {
                            OrderRow(filtered[i], onClick = {
                                navigateTo(com.tatbiqi.app.ui.navigation.Views.ORDER_DETAIL, mapOf("orderId" to filtered[i].id))
                            })
                        }
                    }
                }
            }
        }
}

@Composable
fun OrderRow(order: Order, onClick: () -> Unit) {
    androidx.compose.material3.Card(
        modifier = Modifier.fillMaxWidth().motionPress(onClick),
        colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = com.tatbiqi.app.ui.theme.AppShapes.Card
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(order.customerName, style = MaterialTheme.typography.titleMedium, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                    Text("${order.totalAmount} ${order.currency}", style = MaterialTheme.typography.bodyLarge, color = com.tatbiqi.app.ui.theme.AppColors.Blue)
                }
                com.tatbiqi.app.ui.components.StatusBadge(order.status)
            }
            androidx.compose.foundation.layout.Spacer(Modifier.padding(top = 6.dp))
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                com.tatbiqi.app.ui.components.Pill("🏪 ${segCount(order)} محل", com.tatbiqi.app.ui.theme.AppColors.Blue)
                androidx.compose.foundation.layout.Spacer(Modifier.padding(start = 6.dp))
                com.tatbiqi.app.ui.components.Pill("🕐 ${fmtTime(order.createdAt)}", com.tatbiqi.app.ui.theme.AppColors.Purple)
            }
        }
    }
}

private fun segCount(o: Order): Int =
    try { org.json.JSONArray(o.segmentsJson).length() } catch (e: Exception) { 0 }

private fun fmtTime(ts: Long): String =
    SimpleDateFormat("dd/MM HH:mm", Locale.US).format(Date(ts))
