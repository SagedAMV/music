package com.tatbiqi.app.ui.screens.delivery

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.data.model.Order
import com.tatbiqi.app.ui.components.EmptyState
import com.tatbiqi.app.ui.components.PrimaryButton
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel

/**
 * شاشة التسليم — محتوى تبويب delivery (مطابق renderDelivery في HTML).
 */
@Composable
fun DeliveryScreen(vm: MainViewModel, auth: AuthViewModel) {
    val orders by vm.orders.collectAsState()
    val delivering = orders.filter { it.status == "delivering" }
    val canConfirm = auth.has("delivery.confirm")

    if (delivering.isEmpty()) {
        EmptyState("لا توجد طلبات قيد التسليم", "📦")
    } else {
        LazyColumn(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(delivering) { o -> DeliveryCard(o, canConfirm, vm) }
        }
    }
}

@Composable
fun DeliveryCard(o: Order, canConfirm: Boolean, vm: MainViewModel) {
    var received by remember { mutableStateOf(o.remainingAmount.toString()) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth()) {
                Text("🚚 ${o.customerName}", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.weight(1f))
                Text("${o.totalAmount} ر.ي", style = MaterialTheme.typography.titleMedium)
            }
            if (o.remainingAmount > 0) {
                Text("المتبقي: ${o.remainingAmount} ر.ي", color = Color(0xFF92400E))
            } else {
                Text("مدفوع بالكامل ✅", color = Color(0xFF059669))
            }
            if (o.remainingAmount > 0) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = received, onValueChange = { received = it },
                    label = { Text("المبلغ المقبوض الآن (ر.ي)") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    enabled = canConfirm
                )
                Spacer(Modifier.height(8.dp))
                PrimaryButton("✓ تأكيد التسليم", onClick = {
                    vm.confirmDelivery(o.id, received.toIntOrNull() ?: 0)
                }, enabled = canConfirm)
            } else {
                Spacer(Modifier.height(8.dp))
                PrimaryButton("✓ تأكيد التسليم", onClick = { vm.confirmDelivery(o.id, 0) }, enabled = canConfirm)
            }
        }
    }
}
