package com.tatbiqi.app.data.repository

import com.tatbiqi.app.data.local.AppDatabase
import com.tatbiqi.app.data.model.Customer
import com.tatbiqi.app.data.model.Order
import com.tatbiqi.app.data.model.Product
import com.tatbiqi.app.data.model.Shop
import com.tatbiqi.app.data.model.User
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * المصدر الوحيد للحقيقة (Single Source of Truth).
 * يجمع: المحلي (Room) + السحابي (Firebase) — وهو محاكاة نمط Repository في ملفك الأصلي.
 */
class AppRepository(private val db: AppDatabase) {

    // ---------- Users ----------
    fun observeUsers(): Flow<List<User>> = db.userDao().observeAll()
    suspend fun getAllUsers() = db.userDao().getAll()
    suspend fun getUser(id: String) = db.userDao().getById(id)
    suspend fun getUserByUsername(u: String) = db.userDao().getByUsername(u)
    suspend fun upsertUser(user: User) = db.userDao().upsert(user)
    suspend fun upsertUsers(list: List<User>) = db.userDao().upsertAll(list)
    suspend fun deleteUser(id: String) = db.userDao().deleteById(id)

    // ---------- Shops ----------
    fun observeShops(): Flow<List<Shop>> = db.shopDao().observeAll()
    suspend fun getAllShops() = db.shopDao().getAll()
    suspend fun getShop(id: String) = db.shopDao().getById(id)
    suspend fun upsertShop(shop: Shop) = db.shopDao().upsert(shop)
    suspend fun upsertShops(list: List<Shop>) = db.shopDao().upsertAll(list)
    suspend fun deleteShop(id: String) = db.shopDao().deleteById(id)

    // ---------- Products ----------
    fun observeProducts(): Flow<List<Product>> = db.productDao().observeAll()
    suspend fun getAllProducts() = db.productDao().getAll()
    suspend fun getProduct(id: String) = db.productDao().getById(id)
    suspend fun getProductsByShop(shopId: String) = db.productDao().getByShop(shopId)
    suspend fun upsertProduct(product: Product) = db.productDao().upsert(product)
    suspend fun upsertProducts(list: List<Product>) = db.productDao().upsertAll(list)
    suspend fun deleteProduct(id: String) = db.productDao().deleteById(id)

    // ---------- Customers ----------
    fun observeCustomers(): Flow<List<Customer>> = db.customerDao().observeAll()
    suspend fun getAllCustomers() = db.customerDao().getAll()
    suspend fun getCustomer(id: String) = db.customerDao().getById(id)
    suspend fun upsertCustomer(customer: Customer) = db.customerDao().upsert(customer)
    suspend fun upsertCustomers(list: List<Customer>) = db.customerDao().upsertAll(list)
    suspend fun deleteCustomer(id: String) = db.customerDao().deleteById(id)

    // ---------- Orders ----------
    fun observeOrders(): Flow<List<Order>> = db.orderDao().observeAll()
    fun observeOrdersByStatus(status: String): Flow<List<Order>> = db.orderDao().observeByStatus(status)
    suspend fun getAllOrders() = db.orderDao().getAll()
    suspend fun getOrder(id: String) = db.orderDao().getById(id)
    suspend fun upsertOrder(order: Order) = db.orderDao().upsert(order)
    suspend fun upsertOrders(list: List<Order>) = db.orderDao().upsertAll(list)
    suspend fun deleteOrder(id: String) = db.orderDao().deleteById(id)

    // ---------- Summary helpers (for dashboard/reports) ----------
    suspend fun dashboardStats(): Triple<Int, Int, Int> {
        val orders = db.orderDao().getAll()
        val newOrders = orders.count { it.status == "new" }
        val delivering = orders.count { it.status == "delivering" }
        val totalSales = orders.filter { it.status == "delivered" }
            .sumOf { it.totalAmount }
        return Triple(newOrders, delivering, totalSales)
    }

    suspend fun debtsSum(): Int =
        db.orderDao().getAll().sumOf { it.remainingAmount.coerceAtLeast(0) }

    // ---------- الصورة المشتركة (من واتساب) ----------
    private val _sharedImage = MutableStateFlow<String?>(null)
    private val _sharedImageName = MutableStateFlow("")
    val sharedImage: StateFlow<String?> = _sharedImage.asStateFlow()
    val sharedImageName: StateFlow<String> = _sharedImageName.asStateFlow()
    fun storeSharedImage(dataUrl: String, name: String) {
        _sharedImage.value = dataUrl
        _sharedImageName.value = name
    }
    fun consumeSharedImage() { _sharedImage.value = null }

    /**
     * زرع المستخدم الافتراضي عند أول تشغيل (مطابق admin/admin123 في HTML)
     * — حتى لا تُغلق الشاشة بلا حساب للدخول.
     */
    suspend fun seedIfEmpty() {
        if (db.userDao().getAll().isEmpty()) {
            db.userDao().upsert(User(
                id = "u1",
                username = "admin",
                password = "admin123",
                name = "المالك",
                role = "owner",
                isActive = true,
                workspaceId = "workspace-001",
                permissions = User.defaultPermissions(),
                updatedAt = System.currentTimeMillis()
            ))
            // مستخدم مشتري تجريبي — تسجيل الدخول: buyer / buyer123
            db.userDao().upsert(User(
                id = "u2",
                username = "buyer",
                password = "buyer123",
                name = "مشتري المحلات",
                role = "buyer",
                isActive = true,
                workspaceId = "workspace-001",
                permissions = User.buyerPermissions(),
                updatedAt = System.currentTimeMillis()
            ))
        }
    }
}
