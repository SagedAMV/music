package com.tatbiqi.app.ui.screens.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.data.model.Customer
import com.tatbiqi.app.ui.components.EmptyState
import com.tatbiqi.app.ui.components.LabeledField
import com.tatbiqi.app.ui.components.PrimaryButton
import com.tatbiqi.app.ui.motion.motionPress
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel

@Composable
fun CustomersScreen(
    vm: MainViewModel,
    auth: AuthViewModel,
    navigateTo: (String, Map<String, String>) -> Unit
) {
    val customers by vm.customers.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Customer?>(null) }
    var query by remember { mutableStateOf("") }
    val filtered = customers.filter { query.isBlank() || it.name.contains(query, true) || it.phone.contains(query, true) }

        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("👥 الزبائن", style = MaterialTheme.typography.headlineSmall)
                if (auth.has("customers.manage")) {
                    TextButton(onClick = { editing = null; showDialog = true }) { Text("+ زبون") }
                }
            }
            OutlinedTextField(query, { query = it }, label = { Text("🔍 بحث بالاسم أو الهاتف") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
            if (filtered.isEmpty()) EmptyState("لا يوجد زبائن", "👥")
            else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered) { c ->
                    com.tatbiqi.app.ui.motion.StaggerItem(index = filtered.indexOf(c)) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = com.tatbiqi.app.ui.theme.AppShapes.Card,
                            modifier = Modifier.fillMaxWidth().motionPress { navigateTo(com.tatbiqi.app.ui.navigation.Views.CUSTOMER_DETAIL, mapOf("customerId" to c.id)) }
                        ) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Box(
                                    Modifier.size(44.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                                        .background(com.tatbiqi.app.ui.theme.AppColors.GradGreen),
                                    contentAlignment = androidx.compose.ui.Alignment.Center
                                ) { Text("👤") }
                                androidx.compose.foundation.layout.Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(c.name, style = MaterialTheme.typography.titleMedium, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                                    Text(c.phone, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                if (auth.has("customers.manage")) {
                                    TextButton(onClick = { editing = c; showDialog = true }) { Text("تعديل") }
                                    TextButton(onClick = { vm.deleteCustomer(c.id) }) { Text("🗑", color = MaterialTheme.colorScheme.error) }
                                }
                            }
                        }
                    }
                }
            }
    }

    if (showDialog) {
        CustomerDialog(customer = editing, onDismiss = { showDialog = false },
            onSave = { name, phone, note ->
                vm.saveCustomer(editing?.id, name, phone, note)
                showDialog = false
            })
    }
}

@Composable
fun CustomerDialog(customer: Customer?, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf(customer?.name ?: "") }
    var phone by remember { mutableStateOf(customer?.phone ?: "") }
    var note by remember { mutableStateOf(customer?.note ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (customer == null) "إضافة زبون" else "تعديل زبون") },
        text = {
            Column {
                LabeledField(name, { name = it }, "اسم الزبون")
                Spacer(Modifier.height(8.dp))
                LabeledField(phone, { phone = it }, "رقم الهاتف")
                Spacer(Modifier.height(8.dp))
                LabeledField(note, { note = it }, "ملاحظة")
            }
        },
        confirmButton = {
            PrimaryButton("حفظ") { onSave(name, phone, note) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
