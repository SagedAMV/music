package com.tatbiqi.app.ui.screens.product

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.tatbiqi.app.data.model.Product
import com.tatbiqi.app.ui.components.AppScaffold
import com.tatbiqi.app.ui.components.EmptyState
import com.tatbiqi.app.ui.components.LabeledField
import com.tatbiqi.app.ui.components.PrimaryButton
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel

@Composable
fun ProductsScreen(
    vm: MainViewModel,
    nav: NavHostController,
    auth: AuthViewModel
) {
    val products by vm.products.collectAsState()
    val shops by vm.shops.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Product?>(null) }

    AppScaffold(
        title = "المنتجات",
        actions = {
            if (auth.has("products.manage")) {
                TextButton(onClick = { editing = null; showDialog = true }) { Text("+ منتج") }
            }
        }
    ) {
        if (products.isEmpty()) EmptyState("لا توجد منتجات", "🏷️")
        else LazyColumn(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(products) { p ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                            Text("بيع: ${p.price} • شراء: ${p.buyPrice}", style = MaterialTheme.typography.bodySmall)
                            Text(shops.find { it.id == p.shopId }?.name ?: "", style = MaterialTheme.typography.bodySmall)
                        }
                        if (auth.has("products.manage")) {
                            TextButton(onClick = { editing = p; showDialog = true }) { Text("تعديل") }
                            TextButton(onClick = { vm.deleteProduct(p.id) }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        ProductDialog(product = editing, shops = shops.map { it.name }, onDismiss = { showDialog = false },
            onSave = { name, price, buy, shopName, cat, stock ->
                val shopId = shops.find { it.name == shopName }?.id ?: ""
                vm.saveProduct(editing?.id, name, price, buy, shopId, cat, stock, "")
                showDialog = false
            })
    }
}

@Composable
fun ProductDialog(product: Product?, shops: List<String>, onDismiss: () -> Unit,
                  onSave: (String, Int, Int, String, String, Int) -> Unit) {
    var name by remember { mutableStateOf(product?.name ?: "") }
    var price by remember { mutableStateOf(product?.price?.toString() ?: "") }
    var buy by remember { mutableStateOf(product?.buyPrice?.toString() ?: "") }
    var shop by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf(product?.category ?: "") }
    var stock by remember { mutableStateOf(product?.stock?.toString() ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (product == null) "إضافة منتج" else "تعديل منتج") },
        text = {
            Column {
                LabeledField(name, { name = it }, "اسم المنتج")
                Spacer(Modifier.height(8.dp))
                LabeledField(price, { price = it }, "سعر البيع", isNumber = true)
                Spacer(Modifier.height(8.dp))
                LabeledField(buy, { buy = it }, "سعر الشراء", isNumber = true)
                Spacer(Modifier.height(8.dp))
                LabeledField(shop, { shop = it }, "المحل")
                Spacer(Modifier.height(8.dp))
                LabeledField(stock, { stock = it }, "الكمية", isNumber = true)
            }
        },
        confirmButton = {
            PrimaryButton("حفظ") {
                onSave(name, price.toIntOrNull() ?: 0, buy.toIntOrNull() ?: 0, shop, cat, stock.toIntOrNull() ?: 0)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
