package com.tatbiqi.app.ui.screens.debts

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.data.model.Customer
import com.tatbiqi.app.ui.components.EmptyState
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel

/**
 * شاشة الديون — محتوى تبويب debts (مطابق renderDebts في HTML).
 */
@Composable
fun DebtsScreen(vm: MainViewModel, auth: AuthViewModel) {
    val debtors = vm.debtors()
    val grand = vm.grandDebt()

        LazyColumn(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2))) {
                    Row(Modifier.fillMaxWidth().padding(16.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("إجمالي المستحقات", color = Color(0xFFDC2626), style = MaterialTheme.typography.labelMedium)
                            Text("$grand ر.ي", color = Color(0xFFDC2626), style = MaterialTheme.typography.headlineMedium)
                        }
                        Text("💳", style = MaterialTheme.typography.displaySmall)
                    }
                }
            }
            if (debtors.isEmpty()) {
                item { EmptyState("لا توجد ديون — كل الزبائن سددوا 🎉", "💳") }
            } else {
                items(debtors.size) { i ->
                    val (c, v) = debtors[i]
                    DebtorRow(c, v.first, v.second)
                }
            }
        }
}

@Composable
fun DebtorRow(c: Customer, total: Int, count: Int) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(14.dp)) {
            Text("👤 ${c.name}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text("$total ر.ي", color = Color(0xFFDC2626), style = MaterialTheme.typography.titleMedium)
                Text("$count طلب • ${c.phone}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
