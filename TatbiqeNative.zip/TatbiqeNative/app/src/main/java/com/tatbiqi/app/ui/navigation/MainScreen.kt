package com.tatbiqi.app.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.tatbiqi.app.TatbiqeApp
import com.tatbiqi.app.data.model.User
import com.tatbiqi.app.data.repository.AppRepository
import com.tatbiqi.app.ui.screens.AuthViewModel
import com.tatbiqi.app.ui.screens.MainViewModel
import com.tatbiqi.app.ui.screens.authViewModelFactory
import com.tatbiqi.app.ui.screens.mainViewModelFactory
import com.tatbiqi.app.ui.screens.buyer.BuyerShopOrdersScreen
import com.tatbiqi.app.ui.screens.buyer.BuyerTasksScreen
import com.tatbiqi.app.ui.screens.customer.CustomerDetailScreen
import com.tatbiqi.app.ui.screens.customer.CustomersScreen
import com.tatbiqi.app.ui.screens.dashboard.DashboardScreen
import com.tatbiqi.app.ui.screens.debts.DebtsScreen
import com.tatbiqi.app.ui.screens.delivery.DeliveryScreen
import com.tatbiqi.app.ui.screens.order.OrderDetailScreen
import com.tatbiqi.app.ui.screens.order.OrderFormScreen
import com.tatbiqi.app.ui.screens.order.OrdersScreen
import com.tatbiqi.app.ui.screens.reports.ReportsScreen
import com.tatbiqi.app.ui.screens.settings.SettingsScreen
import com.tatbiqi.app.ui.screens.shop.ShopDetailScreen
import com.tatbiqi.app.ui.screens.shop.ShopsScreen
import com.tatbiqi.app.ui.screens.users.UsersScreen

/**
 * الغلاف المركزي — محاكاة تخطيط HTML (sidebar + main + bottomNav).
 * يعرض شريط سفلي (أول 5 عناصر) + درج جانبي (كل العناصر) + محتوى الحالية.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    app: TatbiqeApp,
    authViewModel: AuthViewModel,
    currentUser: User?,
    onLogout: () -> Unit
) {
    val repo: AppRepository = app.repository
    val mainVm: MainViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = mainViewModelFactory(repo))

    val orders by mainVm.orders.collectAsState()
    val shops by mainVm.shops.collectAsState()
    val customers by mainVm.customers.collectAsState()

    val isBuyer = currentUser?.role == "buyer"
    val allItems = if (isBuyer) NavItems.buyerItems()
        else NavItems.ownerItems(
            newOrders = orders.count { it.status == "new" },
            shopsCount = shops.size,
            customersCount = customers.size,
            deliveringCount = orders.count { it.status == "delivering" }
        )
    val bottomItems = NavItems.bottomItems(allItems)
    val drawerItems = allItems  // في HTML: الشريط الجانبي يعرض كل العناصر

    // حالة العرض الحالية (currentView)
    var currentView by remember { mutableStateOf(if (isBuyer) Views.BUYER_SHOPS else Views.DASHBOARD) }
    var viewParams by remember { mutableStateOf<Map<String, String>>(emptyMap()) }

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    fun navigate(view: String, params: Map<String, String> = emptyMap()) {
        currentView = view
        viewParams = params
    }

    // الشاشات الفرعية (تفاصيل/نماذج) لها شريط علوي خاص بها مع زر رجوع — نخفي شريط الغلاف لها.
    val isDetailView = currentView in setOf(
        Views.ORDER_FORM, Views.ORDER_DETAIL, Views.SHOP_DETAIL,
        Views.CUSTOMER_DETAIL, Views.BUYER_SHOP_ORDERS
    )

    val title = drawerItems.find { it.id == currentView }?.label
        ?: when (currentView) {
            Views.ORDER_FORM -> "طلب جديد"
            Views.ORDER_DETAIL -> "تفاصيل الطلب"
            Views.SHOP_DETAIL -> "تفاصيل المحل"
            Views.CUSTOMER_DETAIL -> "تفاصيل الزبون"
            Views.BUYER_SHOP_ORDERS -> "مهام المحل"
            else -> "تطبيقي"
        }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.fillMaxHeight().padding(end = 40.dp)) {
                // رأس الدرج (مثل sidebar-title)
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("تطبيقي", style = MaterialTheme.typography.titleLarge)
                    Text(currentUser?.name ?: "", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                HorizontalDivider()
                // كل العناصر (مثل sidebar)
                drawerItems.forEach { item ->
                    NavigationDrawerItem(
                        label = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(item.icon, Modifier.padding(end = 8.dp))
                                Text(item.label)
                                if (item.badge > 0) {
                                    Box(Modifier.padding(start = 8.dp).background(
                                        MaterialTheme.colorScheme.primary,
                                        androidx.compose.foundation.shape.CircleShape).padding(horizontal = 8.dp, vertical = 2.dp)) {
                                        Text("${item.badge}", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        },
                        selected = currentView == item.id,
                        onClick = {
                            navigate(item.id)
                            scope.launch { drawerState.close() }
                        }
                    )
                }
                Spacer(Modifier.weight(1f))
                HorizontalDivider()
                NavigationDrawerItem(
                    label = { Row { Text("🚪"); Text("تسجيل الخروج", Modifier.padding(start = 8.dp)) } },
                    selected = false,
                    onClick = onLogout,
                    colors = androidx.compose.material3.NavigationDrawerItemDefaults.colors(selectedContainerColor = Color.Transparent)
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                if (!isDetailView) {
                    androidx.compose.foundation.layout.Box(
                        Modifier
                            .fillMaxWidth()
                            .background(com.tatbiqi.app.ui.theme.AppColors.GradBlue)
                    ) {
                        TopAppBar(
                            title = { Text(title, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) },
                            navigationIcon = {
                                androidx.compose.material3.IconButton(onClick = {
                                    scope.launch { drawerState.open() }
                                }) { Text("☰", style = MaterialTheme.typography.headlineSmall) }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = Color.Transparent,
                                titleContentColor = Color.White
                            )
                        )
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    bottomItems.forEach { item ->
                        val selected = currentView == item.id
                        val scale by androidx.compose.animation.core.animateFloatAsState(
                            targetValue = if (selected) 1.15f else 1f,
                            animationSpec = androidx.compose.animation.core.spring(
                                dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy,
                                stiffness = androidx.compose.animation.core.Spring.StiffnessLow
                            )
                        )
                        NavigationBarItem(
                            selected = selected,
                            onClick = { navigate(item.id) },
                            icon = {
                                Text(
                                    item.icon,
                                    fontSize = MaterialTheme.typography.titleLarge.fontSize,
                                    modifier = Modifier.graphicsLayer {
                                        scaleX = scale; scaleY = scale
                                        if (selected) translationY = -3f * (scale - 1f) * 8f
                                    }
                                )
                            },
                            label = {
                                Text(item.label, style = MaterialTheme.typography.labelSmall)
                            },
                            colors = androidx.compose.material3.NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = com.tatbiqi.app.ui.theme.AppColors.Blue,
                                indicatorColor = com.tatbiqi.app.ui.theme.AppColors.Blue,
                                unselectedIconColor = com.tatbiqi.app.ui.theme.AppColors.Muted,
                                unselectedTextColor = com.tatbiqi.app.ui.theme.AppColors.Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                // 🔥 انتقال ناعم عند تبديل الشاشات (محاكاة page-enter في HTML)
                com.tatbiqi.app.ui.motion.AnimatedPage(
                    key = currentView + viewParams.toString(),
                    modifier = Modifier.fillMaxSize()
                ) {
                when (currentView) {
                    Views.DASHBOARD -> DashboardScreen(mainVm, authViewModel, currentUser, navigateTo = { v, p -> navigate(v, p) })
                    Views.ORDERS -> OrdersScreen(mainVm, authViewModel, currentUser, navigateTo = { v, p -> navigate(v, p) })
                    Views.ORDER_FORM -> OrderFormScreen(mainVm, authViewModel, orderId = viewParams["orderId"], onBack = { navigate(Views.ORDERS) })
                    Views.ORDER_DETAIL -> OrderDetailScreen(mainVm, authViewModel, orderId = viewParams["orderId"] ?: "", onBack = { navigate(Views.ORDERS) })
                    Views.SHOPS -> ShopsScreen(mainVm, authViewModel, navigateTo = { v, p -> navigate(v, p) })
                    Views.SHOP_DETAIL -> ShopDetailScreen(mainVm, authViewModel, shopId = viewParams["shopId"] ?: "", onBack = { navigate(Views.SHOPS) })
                    Views.CUSTOMERS -> CustomersScreen(mainVm, authViewModel, navigateTo = { v, p -> navigate(v, p) })
                    Views.CUSTOMER_DETAIL -> CustomerDetailScreen(mainVm, authViewModel, customerId = viewParams["customerId"] ?: "", onBack = { navigate(Views.CUSTOMERS) })
                    Views.BUYER_SHOPS -> BuyerTasksScreen(mainVm, authViewModel, navigateTo = { v, p -> navigate(v, p) })
                    Views.BUYER_SHOP_ORDERS -> BuyerShopOrdersScreen(mainVm, authViewModel, shopId = viewParams["shopId"] ?: "", onBack = { navigate(Views.BUYER_SHOPS) })
                    Views.DELIVERY -> DeliveryScreen(mainVm, authViewModel)
                    Views.DEBTS -> DebtsScreen(mainVm, authViewModel)
                    Views.REPORTS -> ReportsScreen(mainVm, authViewModel)
                    Views.USERS -> UsersScreen(mainVm, authViewModel)
                    Views.SETTINGS -> SettingsScreen(mainVm, authViewModel, app.syncManager, onBack = { navigate(Views.DASHBOARD) })
                    else -> DashboardScreen(mainVm, authViewModel, currentUser, navigateTo = { v, p -> navigate(v, p) })
                }
                }
            }
        }
    }
}
