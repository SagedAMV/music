package com.tatbiqi.app.ui.navigation

/**
 * حالة التنقل المركزية — محاكاة `currentView` + `viewParams` في HTML.
 * بدل نظام Routes المعقّد، نستخدم متغيّر view واحد مثل HTML تماماً.
 */
data class AppViewState(
    val view: String = "dashboard",          // currentView في HTML
    val params: Map<String, String> = emptyMap()   // viewParams في HTML
)

object Views {
    const val LOGIN = "login"
    const val DASHBOARD = "dashboard"
    const val ORDERS = "orders"
    const val ORDER_FORM = "order-form"
    const val ORDER_DETAIL = "order-detail"
    const val SHOPS = "shops"
    const val SHOP_DETAIL = "shop-detail"
    const val CUSTOMERS = "customers"
    const val CUSTOMER_DETAIL = "customer-detail"
    const val BUYER_SHOPS = "buyer-shops"
    const val BUYER_SHOP_ORDERS = "buyer-shop-orders"
    const val DELIVERY = "delivery"
    const val DEBTS = "debts"
    const val REPORTS = "reports"
    const val USERS = "users"
    const val SETTINGS = "settings"
    const val NO_PERM = "no-perm"

    /** الترتيب المنطقي للشاشات الرئيسية (كما في getNavItems). */
    val ALL = listOf(
        DASHBOARD, ORDERS, SHOPS, CUSTOMERS, BUYER_SHOPS,
        DELIVERY, DEBTS, REPORTS, USERS, SETTINGS
    )
}
