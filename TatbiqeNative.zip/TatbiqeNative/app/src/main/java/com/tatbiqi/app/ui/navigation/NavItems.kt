package com.tatbiqi.app.ui.navigation

/**
 * عناصر التنقل — مطابقة تماماً لـ getNavItems() في HTML.
 * كل عنصر: id (view) + label + icon (إيموجي مثل HTML) + badge اختياري.
 */
data class NavItem(
    val id: String,
    val label: String,
    val icon: String,
    val badge: Int = 0
)

object NavItems {

    /** ترتيب المالك (10 عناصر) — مطابق لـ getNavItems owner. */
    fun ownerItems(
        newOrders: Int = 0,
        shopsCount: Int = 0,
        customersCount: Int = 0,
        deliveringCount: Int = 0
    ) = listOf(
        NavItem("dashboard", "لوحة التحكم", "🏠"),
        NavItem("orders", "الطلبات", "📋", newOrders),
        NavItem("shops", "المحلات", "🏪", shopsCount),
        NavItem("customers", "الزبائن", "👥", customersCount),
        NavItem("buyer-shops", "مهام المشتري", "🛍️"),
        NavItem("delivery", "التسليم", "📦", deliveringCount),
        NavItem("debts", "الديون", "💳"),
        NavItem("reports", "التقارير", "📊"),
        NavItem("users", "المستخدمين", "👤"),
        NavItem("settings", "الإعدادات", "⚙️")
    )

    /** ترتيب المشتري (6 عناصر) — مطابق لـ getNavItems buyer. */
    fun buyerItems() = listOf(
        NavItem("buyer-shops", "المحلات الذكية", "🛍️"),
        NavItem("delivery", "التسليم", "📦"),
        NavItem("orders", "الطلبات", "📋"),
        NavItem("customers", "الزبائن", "👥"),
        NavItem("reports", "التقارير", "📊"),
        NavItem("settings", "الإعدادات", "⚙️")
    )

    /** أول 5 عناصر فقط — مطابق لـ bottomNav = items.slice(0,5). */
    fun bottomItems(items: List<NavItem>): List<NavItem> = items.take(5)

    /** العناصر المتبقية للدرج (من 6 فما بعد). */
    fun drawerOnlyItems(items: List<NavItem>): List<NavItem> = items.drop(5)
}
